param(
    [switch]$Debug
)

<#
.SYNOPSIS
CPR-Base (Captive Portal Base Observer)

.DESCRIPTION
Version: 1.0.0_RC1.25
Author: steve.horton@optum.com
Date: 16-Jul-2026

Version 1.0.0_RC1.25:
  - NEW: Get-BaseCapNetworkContext - this process gathers its OWN ssid/ip/gw/dns
    (netsh wlan + Get-NetIPConfiguration). The base runner is launched by Task
    Scheduler as a separate process and never shares scope with WW_main.ps1, so
    previously every base-mode cap_portal_* row in Splunk had empty network
    context. Unavailable values stay explicitly empty and the reason is logged.
  - NEW: normalized cap_portal_remediation_passed/failed payloads carry the full
    flat contract (EvtTime, action, machine, user, ssid, url, port, ip, gw, dns,
    vpn_state, portal_type, status, reason). EvtTime is stamped locally at event
    creation, before queueing.
  - NEW: url/port/protocol/fqdn/ssid/ip/gw/dns are read from the richer
    remediation state file WW_main.ps1 now writes; the live local reading wins,
    the handed-over value is the fallback.
  - CLARITY: the legacy action="network_state_change" queue event is preserved
    but now stamped event_class="legacy_haystack" so it can never be mistaken
    for a normalized remediation outcome row.

Version 1.0.0_RC1.20 (initial):
  - NEW: AlwaysOn-native observer mode for captive portal handling
  - Designed for users with uhg_always_on.xml or uhg_always_on_elevated.xml VPN profiles
  - Cisco Secure Client XML changes in those profiles now handle captive portal detection
    and browser launch natively - this script observes and lets the client do its job
  - Does NOT kill Cisco browser processes - Cisco client is expected to be running them
  - Does NOT open Edge or any browser - native Cisco handling is preferred
  - Polls connectivity every $CheckIntervalSec seconds for up to $ObserveTimeoutSeconds
  - Logs VPN state on every poll cycle for full visibility into what Cisco client is doing
  - On success: writes SUCCESS_NATIVE completion flag, exits cleanly
  - On timeout: writes TIMEOUT_NATIVE flag, fires captive_portal_browser (Event 777) to
    escalate to WW_cap_portal_runner.ps1 as fallback - full runner takes over from here
  - Reads cap_portal_remediation_active.flag for portal context (portal_type, gateway_ip,
    ssid) - used for logging only in this version
  - Triggered by: Task Scheduler on FlareGun Event 778 (captive_portal_browser_base)

Purpose: Observe captive portal resolution in USER context without interfering with
         Cisco Secure Client's native captive portal handling
Triggered by: Task Scheduler on FlareGun Event 778

Task Scheduler Configuration:
  Program: conhost.exe
  Arguments: --headless powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -File "C:\ProgramData\WhiteWalker\WW_cap_portal_runner_base.ps1"
#>

# Configuration
$LogPath               = "C:\ProgramData\WhiteWalker\logs\white_walker.cap_portal_base.log"
$FlagFile              = "C:\ProgramData\WhiteWalker\portal_complete.flag"
# ---------------------------------------------------------------------------
# FAIL-SAFE DEFAULTS ONLY (RC2.2, Required E).
# Main.Configuration.ps1 is the source of truth for every value in this block.
# Main writes its EFFECTIVE values into the dispatch artifact as
# `timing_contract`; Resolve-BaseTimingContract below applies them at startup.
# These literals are used ONLY when the artifact is absent or unreadable
# (manual/legacy launch) and are asserted against Main.Configuration.ps1 by a
# drift test (tests/CPR_RC2.CapPortalConfigContract.Tests.ps1).
# ---------------------------------------------------------------------------
$ValidationSite        = "https://www.optum.com"
$BasePreflightUrl      = "https://gateway.optum.com" # Must match Main.Configuration.ps1 $NewPreflightURL.
$BasePreflightTimeoutMs = 3000
# The empirical preflight is polled through the observation window, not probed
# once: a portal can start redirecting several seconds after Base starts.
$BasePreflightMaxProbes = 6
# Required D - bounded network-settle gate before Base's first preflight.
$BaseSiteTimeoutSec             = 3      # seconds per Test-SiteReachability call
$BaseNetworkReadyEnabled        = $true
$BaseNetworkReadyMaxWaitMs      = 8000
$BaseNetworkReadyPollIntervalMs = 500
$BaseNetworkReadyGatewayTimeoutMs = 750
$BaseNetworkReadyDnsTimeoutMs   = 1500
$BaseWebHelper301SuppressPreflight = $true # bool, accepted active Main 301 evidence suppresses blocked gateway probes
$BaseWebHelper301MaxAgeSec      = 180   # seconds, re-check embedded Main evidence freshness
$BaseWebHelper301MaxRecords     = 256   # bounded records per noisy EventID 301 query
# ---------------------------------------------------------------------------
# TIMER PARITY (Required E). Base is standalone and never inherits Main scope,
# so these literals MIRROR Main.Configuration.ps1 and are asserted by a drift
# test (tests/CPR_RC2.CapPortalRecovery.Tests.ps1):
#
#   $ObserveTimeoutSeconds (120) == Main $CapPortalBaseTimeoutSeconds (120)
#                                == Main $CaptivePortalTimeout        (120)
#   $CheckIntervalSec      (10)  == Main $CapPortalBaseCheckIntervalSec (10)
#
# Main is the source of truth: when the dispatch artifact carries
# base_observe_timeout_sec / base_check_interval_sec, those win and these
# literals are only the standalone fallback. Full-runner-only waits
# ($InitialWaitSeconds = 150, $FinalWaitSeconds = 30 in
# WW_cap_portal_runner.ps1) have no Base equivalent - Base never launches a
# browser - and are deliberately NOT mirrored.
# ---------------------------------------------------------------------------
$ObserveTimeoutSeconds = 120   # seconds to observe before (optionally) escalating
$CheckIntervalSec      = 10    # connectivity poll interval during observation window
# Base -> Full (Event 777) escalation. Mirrors Main $CapPortalBaseAllowFullEscalation.
# FAIL-SAFE DEFAULT: $false. The dispatch artifact's base_allow_full_escalation
# property overrides it; a missing/undefined property means NO escalation.
$BaseAllowFullEscalation = $false
# A handoff artifact older than this no longer describes the live network.
$MaxHandoffAgeSeconds  = 900
$StateDir              = "C:\ProgramData\WhiteWalker"
$LogDir                = Join-Path $StateDir "logs"
$SyslogQueueFile       = Join-Path $LogDir "haystack_syslog_queue.jsonl"
$RemediationStateFile  = "C:\ProgramData\WhiteWalker\cap_portal_remediation_active.flag"
# RC2.1 (Required G): SYSTEM owns $RemediationStateFile. This USER-context
# process may be denied a rewrite of it ("Access to the path ...
# cap_portal_remediation_active.flag is denied"), so its findings are ALWAYS
# written atomically to this separate user-result/handback artifact inside the
# narrowly scoped spool directory, which Main (SYSTEM) consumes. The SYSTEM
# artifact is still updated opportunistically but is never required.
$BaseHandbackFile      = Join-Path $LogDir "spool\cap_portal_base_handback.json"
$VpnCliPath            = "C:\Program Files (x86)\Cisco\Cisco Secure Client\vpncli.exe"
$EscalationEventId     = 777   # Event ID for captive_portal_browser - full runner fallback
$EscalationEventSource = "WhiteWalkerFlareGun"
# Cisco Secure Client's own WebHelper (csc_webhelper / WebView2 host) writes a
# free-form debug trace to the "Cisco Secure Client" Windows event log under
# EventID 301 whenever its embedded browser finishes navigating. This read is
# READ-ONLY and purely additive: it never writes to, alters, or competes with
# the independent NEEDLE|Cisco Secure Client|301||CaptivePotal_Action|all
# HayStack pipeline that already ships this same event to Splunk today.
$CiscoWebHelperLogName = 'Cisco Secure Client'
$CiscoWebHelperProviderName = 'csc_webhelper'
$CiscoWebHelperEventId = 301
# Cisco's WebView2 can pop the portal and emit EventID 301 BEFORE FlareGun
# Event 778 launches this runner, so the event query starts this many seconds
# before Base started. Tunable; bounded to keep the query cheap.
$CiscoWebHelperLookbackSeconds = 180

# Tee logging engine - dot-sourced so this USER-context script can ship the same
# cap_portal_remediation_passed / cap_portal_remediation_failed telemetry that
# WW_main.ps1 ships for full-mode runs. Write-TeeLog is a safe no-op if
# $HaystackEnabled/$TeeEnabled aren't set globally - but since this script runs
# standalone (launched by Task Scheduler as its own process, never inheriting
# WW_main.ps1's scope), the three switches are hardcoded here to match the
# literal values WW_main.ps1 uses today, rather than inherited.
$global:HaystackEnabled = $true
$global:TeeEnabled      = $true
$global:TeeEventsFile   = "C:\ProgramData\WhiteWalker\WW_tee_events.psd1"
. "C:\ProgramData\WhiteWalker\WW_tee.ps1"

function Initialize-BaseCapPortalLogger {
    if (-not (Test-Path $StateDir)) {
        try {
            New-Item -Path $StateDir -ItemType Directory -Force | Out-Null
        } catch {
            Write-Host "ERROR: Cannot create state directory $StateDir - $_"
            exit 1
        }
    }

    if (-not (Test-Path $LogPath)) {
        try {
            New-Item -Path $LogPath -ItemType File -Force | Out-Null
        } catch {
            Write-Host "WARNING: Cannot create log file $LogPath - $_"
        }
    }
}

function Write-BaseCapLog {
    param([string]$Message, [string]$Level = "INFO")
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff zzz")
    $logLine = "$ts [BASE] [$Level] $Message"

    try {
        Add-Content -Path $LogPath -Value $logLine -Encoding UTF8 -ErrorAction SilentlyContinue
    } catch {
        # Fail silently if can't write to log
    }

    if ($Debug) {
        Write-Host $logLine
    }
}

function Write-BaseCapTee {
    <#
    .SYNOPSIS
    Truthful, fail-soft telemetry wrapper for the standalone Base runner.

    .DESCRIPTION
    Base runs in USER context as its own process, so a tee event that is
    dropped (tag missing from the active sticky WW_tee_events.psd1 profile) or
    refused (queue file ACL denies the interactive user) used to vanish with no
    trace at all - exactly how the Base structured events went missing from
    haystack_syslog_queue.jsonl while the raw EventID 301 needle still landed.
    Write-TeeLog -PassThru reports the real outcome; this logs the exact reason
    token (queued | tag_not_in_profile | haystack_disabled | tee_disabled |
    access_denied | error) and never blocks or fails the observer.
    #>
    param(
        [Parameter(Mandatory)][string]$Tag,
        [Parameter(Mandatory)][hashtable]$Data
    )

    try {
        $result = Write-TeeLog $Tag $Data -PassThru
        if ($null -eq $result) {
            Write-BaseCapLog "tee '$Tag' result=unknown (no result returned)" "DEBUG"
            return $null
        }
        $level = if ($result.Queued) { 'DEBUG' } elseif ($result.Reason -in @('access_denied', 'error')) { 'WARN' } else { 'INFO' }
        $detail = if ($result.Error) { " error='$($result.Error)'" } else { "" }
        Write-BaseCapLog "tee '$Tag' queued=$($result.Queued) reason=$($result.Reason)$detail" $level
        return $result
    } catch {
        Write-BaseCapLog "tee '$Tag' failed: $_ (reason=error)" "WARN"
        return $null
    }
}

function Get-CiscoWebHelperQueryParameter {
    param(
        [string]$Url = "",
        [string]$ParameterName = ""
    )

    if ([string]::IsNullOrEmpty($Url) -or [string]::IsNullOrEmpty($ParameterName)) {
        return ""
    }

    try {
        $escapedName = [regex]::Escape($ParameterName)
        $match = [regex]::Match($Url, "(?i)(?:[?&])$escapedName=([^&#]*)")
        if (-not $match.Success) { return "" }
        return [Uri]::UnescapeDataString($match.Groups[1].Value)
    } catch {
        return ""
    }
}

function Get-CiscoWebHelperFinalUrlPort {
    param([string]$Url = "")

    if ([string]::IsNullOrEmpty($Url)) { return 0 }
    $portPattern = '^[a-zA-Z][a-zA-Z0-9+.-]*://[^/?#]*?:(\d{1,5})(?=[/?#]|$)'
    try {
        $uri = [Uri]$Url
        $match = [regex]::Match($Url, $portPattern)
        if ($match.Success -and $uri.IsDefaultPort) {
            return [int]$match.Groups[1].Value
        }
        if ($match.Success) {
            return [int]$match.Groups[1].Value
        }
        if (-not $uri.IsDefaultPort -and $uri.Port -gt 0) {
            return [int]$uri.Port
        }
    } catch {
        try {
            $match = [regex]::Match($Url, $portPattern)
            if ($match.Success) { return [int]$match.Groups[1].Value }
        } catch {}
    }
    return 0
}

function Get-CiscoWebHelperQueryParameterAny {
    <#
    First non-empty value among several real-world parameter spellings.
    Xfinity, for example, publishes the AP radio MAC as "cm" where Meraki and
    GuestInternet publish "ap_mac".
    #>
    param(
        [string]$Url = "",
        [string[]]$ParameterNames = @()
    )

    foreach ($name in $ParameterNames) {
        $value = Get-CiscoWebHelperQueryParameter -Url $Url -ParameterName $name
        if (-not [string]::IsNullOrWhiteSpace($value)) { return $value }
    }
    return ""
}

function ConvertFrom-CiscoWebHelperEventText {
    <#
    Normalizes a real Windows event message before regex matching.

    Cisco's EventID 301 text reaches us in several shapes: the plain event
    message, a JSON-escaped copy (\" and \\), and Unicode-escaped copies
    (\u0027 / \u0022) when it has been round-tripped through a needle/queue.
    Normalizing first is what makes one tolerant regex work for all of them.
    #>
    param([string]$Body = "")

    if ([string]::IsNullOrEmpty($Body)) { return "" }

    $text = $Body
    try {
        $text = [regex]::Replace($text, '(?i)\\u0027', "'")
        $text = [regex]::Replace($text, '(?i)\\u0022', '"')
        $text = $text -replace '\\"', '"'
        $text = $text -replace "\\'", "'"
        $text = $text -replace '\\\\', '\'
        # Smart quotes occasionally survive localization/copy-paste.
        $text = $text -replace [char]0x2018, "'" -replace [char]0x2019, "'"
        $text = $text -replace [char]0x201C, '"' -replace [char]0x201D, '"'
    } catch {
        return $Body
    }
    return $text
}

function Get-CiscoWebHelperUrlFromText {
    <#
    Pulls one labelled URL out of the normalized event text. Tolerates single
    or double quotes, an optional colon, and extra whitespace/wording between
    the label and the URL; falls back to an unquoted token.
    #>
    param(
        [string]$Text = "",
        [Parameter(Mandatory)][string]$LabelPattern
    )

    if ([string]::IsNullOrEmpty($Text)) { return "" }
    try {
        $quoted = [regex]::Match($Text, "(?is)$LabelPattern\s*:?\s*(['""])(?<url>.+?)\1")
        if ($quoted.Success) { return $quoted.Groups['url'].Value.Trim() }

        $bare = [regex]::Match($Text, "(?is)$LabelPattern\s*:?\s*(?<url>[a-z][a-z0-9+.-]*://[^\s'""]+)")
        if ($bare.Success) { return $bare.Groups['url'].Value.TrimEnd('.', ',', ';') }
    } catch { }
    return ""
}

function ConvertFrom-CiscoWebHelperNavigationBody {
    <#
    Parses one Cisco Secure Client EventID 301 WebHelper navigation record.

    CONTRACT: this is OPTIONAL corroborating evidence. It never decides whether
    a captive portal exists and never influences an ISE posture rescan. The
    navigated URL (the portal) and the final URL (usually
    msftconnecttest.com) are parsed INDEPENDENTLY and must never be conflated.
    #>
    param([string]$Body = "")

    $result = [PSCustomObject]@{
        Parsed = $false; NavigatedUrl = ""; FinalUrl = ""; FinalUrlPort = 0
        ProcessId = ""; ThreadId = ""; ApName = ""; ApTags = ""; ApMac = ""
        Sip = ""; Org = ""; Ui = ""; Psid = ""; LoginUrl = ""; Ma = ""
        Os = ""; ApiDomain = ""; OsName = ""; OsVersion = ""; BrowserName = ""
        BrowserVersion = ""; DeviceType = ""; TraceId = ""
    }
    if ([string]::IsNullOrEmpty($Body)) { return $result }

    try {
        $text = ConvertFrom-CiscoWebHelperEventText -Body $Body

        $navigatedUrl = Get-CiscoWebHelperUrlFromText -Text $text -LabelPattern 'navigated\s+successfully\s+to\s+URL'
        $finalUrl     = Get-CiscoWebHelperUrlFromText -Text $text -LabelPattern 'Final\s+URL'
        $pidMatch = [regex]::Match($text, 'PID\s*=\s*(\d+)')
        $tidMatch = [regex]::Match($text, 'TID\s*=\s*(\d+)')
        if ($pidMatch.Success) { $result.ProcessId = $pidMatch.Groups[1].Value }
        if ($tidMatch.Success) { $result.ThreadId = $tidMatch.Groups[1].Value }

        if (-not [string]::IsNullOrEmpty($navigatedUrl)) {
            $result.NavigatedUrl = $navigatedUrl
            $result.Parsed = $true
            # Single-spelling fields.
            $fields = @{
                ApName = 'ap_name'; ApTags = 'ap_tags'; Sip = 'SIP'
                Org = 'ORG'; Ui = 'UI'; Psid = 'PSID'; LoginUrl = 'login_url'
                Ma = 'MA'; Os = 'OS'; ApiDomain = 'api_domain'
            }
            foreach ($field in $fields.GetEnumerator()) {
                $result.($field.Key) = Get-CiscoWebHelperQueryParameter -Url $result.NavigatedUrl -ParameterName $field.Value
            }
            # Vendor aliases seen on real Xfinity/Comcast portals.
            $result.ApMac          = Get-CiscoWebHelperQueryParameterAny -Url $result.NavigatedUrl -ParameterNames @('ap_mac', 'cm')
            $result.OsName         = Get-CiscoWebHelperQueryParameterAny -Url $result.NavigatedUrl -ParameterNames @('cp_da_osname')
            $result.OsVersion      = Get-CiscoWebHelperQueryParameterAny -Url $result.NavigatedUrl -ParameterNames @('cp_da_osversion')
            $result.BrowserName    = Get-CiscoWebHelperQueryParameterAny -Url $result.NavigatedUrl -ParameterNames @('cp_da_browsername')
            $result.BrowserVersion = Get-CiscoWebHelperQueryParameterAny -Url $result.NavigatedUrl -ParameterNames @('cp_da_browserversion')
            $result.DeviceType     = Get-CiscoWebHelperQueryParameterAny -Url $result.NavigatedUrl -ParameterNames @('cp_da_type')
            $result.TraceId        = Get-CiscoWebHelperQueryParameterAny -Url $result.NavigatedUrl -ParameterNames @('traceId', 'trace_id', 'traceid')
        }
        if (-not [string]::IsNullOrEmpty($finalUrl)) {
            # final_url is NOT the captive portal URL - keep it separate.
            $result.FinalUrl = $finalUrl
            $result.FinalUrlPort = Get-CiscoWebHelperFinalUrlPort -Url $result.FinalUrl
            $result.Parsed = $true
        }
    } catch {
        Write-BaseCapLog "Cisco WebHelper Event 301 body parse failed: $_" "DEBUG"
    }
    # RC2.1 (Required D): no per-record log line here. One EventID 301 record
    # that carries no navigation URL used to be re-parsed and re-logged on every
    # poll; the caller now reports a concise per-cycle count instead.
    return $result
}

function Get-CiscoWebHelperDedupeKey {
    <#
    Event identity for de-duplication.

    PID alone was wrong: one csc_webhelper PID emits MANY navigation stages for
    a single portal login, so PID-only de-dupe threw away every stage after the
    first. The key is record id + event time + PID + navigated/final URL, which
    keeps distinct navigation stages while suppressing repeated reads of the
    same record.
    #>
    param(
        [string]$RecordId = "",
        $EventTime = $null,
        [string]$ProcessId = "",
        [string]$NavigatedUrl = "",
        [string]$FinalUrl = ""
    )

    $timeToken = if ($EventTime) { ([datetime]$EventTime).ToString('o') } else { '' }
    if ($RecordId) { return "record:$RecordId" }
    return ("fallback:t:{0}|pid:{1}|nav:{2}|fin:{3}" -f $timeToken, $ProcessId, $NavigatedUrl, $FinalUrl)
}

function Get-CiscoWebHelperNavigationEvent {
    <#
    RC2.1 (Required D): -SeenRecordIds is a persistent set of event record ids
    that have ALREADY been examined. Records in that set are skipped before they
    are re-parsed, so a non-navigation EventID 301 record is examined exactly
    once instead of on every poll. NonNavigationCount reports how many newly
    examined records carried no navigation URL, so the caller can emit a single
    concise per-cycle count instead of one DEBUG line per record per poll.
    Distinct navigation stages and the real-Xfinity parsing are unchanged.
    #>
    param(
        [Parameter(Mandatory)][datetime]$Since,
        [int]$MaxEvents = 256,
        [hashtable]$SeenProcessIds = @{},
        [hashtable]$SeenRecordIds = @{}
    )
    $empty = [PSCustomObject]@{
        Found = $false; NavigatedUrl = ""; FinalUrl = ""; FinalUrlPort = 0
        ProcessId = ""; ThreadId = ""; ApName = ""; ApTags = ""; ApMac = ""
        Sip = ""; Org = ""; Ui = ""; Psid = ""; LoginUrl = ""; Ma = ""
        Os = ""; ApiDomain = ""; OsName = ""; OsVersion = ""; BrowserName = ""
        BrowserVersion = ""; DeviceType = ""; TraceId = ""
        DedupeKey = ""; EventRecordId = ""; EventTime = $null; Error = ""
        NonNavigationCount = 0; ExaminedCount = 0; SkippedSeenCount = 0
    }
    try {
        $events = @(Get-WinEvent -FilterHashtable @{
            LogName = $CiscoWebHelperLogName
            ProviderName = $CiscoWebHelperProviderName
            Id = $CiscoWebHelperEventId
            StartTime = $Since
        } -MaxEvents $MaxEvents -ErrorAction Stop |
            Sort-Object @{Expression='TimeCreated';Descending=$true}, @{Expression='RecordId';Descending=$true})
        if ($events.Count -eq 0) {
            $empty.Error = "No matching Cisco WebHelper navigation events found since $Since"
            return $empty
        }
        foreach ($event in $events) {
            $recordId = ""
            try { if ($null -ne $event.RecordId) { $recordId = [string]$event.RecordId } } catch { }

            $recordIdentity = if ($recordId) {
                "record:$recordId"
            } else {
                "fallback:$($event.TimeCreated.ToString('o'))|$($event.ProviderName)|$($event.Id)|$([string]$event.Message)"
            }
            # Already examined in an earlier cycle - never re-parse or re-log it.
            if ($SeenRecordIds.ContainsKey($recordIdentity)) {
                $empty.SkippedSeenCount++
                continue
            }
            $SeenRecordIds[$recordIdentity] = $true

            $parsed = ConvertFrom-CiscoWebHelperNavigationBody -Body ([string]$event.Message)
            $empty.ExaminedCount++
            if (-not $parsed.Parsed -or [string]::IsNullOrWhiteSpace($parsed.NavigatedUrl)) {
                $empty.NonNavigationCount++
                continue
            }
            try {
                $navigatedUri = [Uri]$parsed.NavigatedUrl
                if (-not $navigatedUri.IsAbsoluteUri -or -not $navigatedUri.Host -or
                    $navigatedUri.Scheme -notin @('http','https')) {
                    $empty.NonNavigationCount++
                    continue
                }
            } catch {
                $empty.NonNavigationCount++
                continue
            }
            $key = Get-CiscoWebHelperDedupeKey -RecordId $recordId -EventTime $event.TimeCreated `
                -ProcessId $parsed.ProcessId -NavigatedUrl $parsed.NavigatedUrl -FinalUrl $parsed.FinalUrl
            if ($SeenProcessIds.ContainsKey($key)) {
                $empty.SkippedSeenCount++
                continue
            }
            foreach ($property in $parsed.PSObject.Properties) {
                if ($property.Name -ne 'Parsed') { $empty.($property.Name) = $property.Value }
            }
            $empty.Found = $true
            $empty.DedupeKey = $key
            $empty.EventRecordId = $recordId
            $empty.EventTime = $event.TimeCreated
            return $empty
        }
        $empty.Error = "All matching Cisco WebHelper navigation events were already seen or unparsable"
    } catch {
        $empty.Error = [string]$_.Exception.Message
    }
    return $empty
}

# These helpers must remain callable from the main scope. They are intentionally
# kept fail-soft for standalone base-runner execution.
function Get-BaseCapUrlDetails {
    param([string]$Url = "")

    $details = @{ url = $Url; protocol = ''; fqdn = ''; port = '' }
    try {
        $uri = [Uri]$Url
        $details.protocol = $uri.Scheme
        $details.fqdn = $uri.Host
        $details.port = if ($uri.IsDefaultPort) {
            if ($uri.Scheme -eq 'http') { '80' } elseif ($uri.Scheme -eq 'https') { '443' } else { '' }
        } else { [string]$uri.Port }
    } catch { }
    return $details
}

function Get-BaseCapRedirectType {
    <#
    Mirror of Main.Network.ps1:Get-RedirectType. Classification only - Base
    never acts on the result.
    #>
    param([string]$RedirectUrl = "")

    if ([string]::IsNullOrWhiteSpace($RedirectUrl) -or $RedirectUrl -eq 'UNKNOWN') { return 'UNKNOWN' }

    $url = $RedirectUrl.ToLower()
    if ($url -match 'isepsn') { return 'ISE_EMPLOYEE' }
    elseif ($url -match 'isegst') { return 'ISE_GUEST' }
    else { return 'NON_ISE' }
}

function Set-BaseCapPreflightStatus {
    <#
    Shared classification for a preflight response. Mirrors
    Main.Network.ps1:Test-Redirect semantics: ISE answers a probe with a
    non-standard HTTP 200 that still carries a Location header, so ANY 2xx/3xx
    with Location is a redirect - not just a 3xx.
    #>
    param([Parameter(Mandatory)]$Result)

    $code = 0
    [void][int]::TryParse([string]$Result.http_status, [ref]$code)

    if ($Result.redirect_url -and $code -ge 200 -and $code -lt 400) {
        $Result.status = 'redirect'
        $Result.classification = 'REDIRECT'
        $Result.reason = if ($code -ge 300) { 'http_3xx_location' } else { 'http_2xx_with_location' }
    } elseif ($Result.http_status -in @('200', '404')) {
        $Result.status = 'online'
        $Result.classification = 'ONLINE'
        $Result.reason = 'no_redirect'
    } else {
        $Result.status = 'unreachable'
        $Result.classification = 'INCONCLUSIVE'
        if (-not $Result.reason) { $Result.reason = 'unexpected_http_status' }
    }
    return $Result
}

function Test-BaseCapPreflight {
    <#
    Read-only equivalent of Main.Network.ps1:Get-NwCheckResult.  It deliberately
    performs one bounded GET without following Location and never remediates.
    #>
    param(
        [string]$Url = $BasePreflightUrl,
        [int]$TimeoutMs = $BasePreflightTimeoutMs
    )

    $started = Get-Date
    $result = [ordered]@{
        observation_time = $started.ToString('o'); probe_url = $Url; status = 'unreachable'
        classification = 'INCONCLUSIVE'
        http_status = ''; redirect_url = ''; redirect_type = ''; protocol = ''; fqdn = ''; port = ''
        duration_ms = 0; attempt = 1; reason = ''; error_message = ''
    }
    try {
        $request = [System.Net.HttpWebRequest]::Create($Url)
        $request.AllowAutoRedirect = $false
        $request.Timeout = $TimeoutMs
        $response = $request.GetResponse()
        $result.http_status = [string][int]$response.StatusCode
        $result.redirect_url = [string]$response.Headers['Location']
        $response.Close()
        $result = Set-BaseCapPreflightStatus -Result $result
    } catch [System.Net.WebException] {
        $response = $_.Exception.Response
        if ($response) {
            $result.http_status = [string][int]$response.StatusCode
            $result.redirect_url = [string]$response.Headers['Location']
            $response.Close()
            $result = Set-BaseCapPreflightStatus -Result $result
        } else {
            # Timeout / DNS / transport failure => INCONCLUSIVE. Never "online",
            # and never proof that no captive portal exists. Same reason token
            # Main uses, with the raw message kept alongside it.
            $result.reason = 'transport_failure'
            $result.error_message = [string]$_.Exception.Message
            $result.classification = 'INCONCLUSIVE'
        }
    } catch {
        $result.reason = 'transport_failure'
        $result.error_message = [string]$_.Exception.Message
        $result.classification = 'INCONCLUSIVE'
    }
    $result.duration_ms = [math]::Round(((Get-Date) - $started).TotalMilliseconds)
    if ($result.redirect_url) {
        $urlDetails = Get-BaseCapUrlDetails -Url $result.redirect_url
        $result.protocol = $urlDetails.protocol; $result.fqdn = $urlDetails.fqdn; $result.port = $urlDetails.port
        $result.redirect_type = Get-BaseCapRedirectType -RedirectUrl $result.redirect_url
    }
    return [PSCustomObject]$result
}

function Get-BaseCapEffectiveRedirectType {
    <#
    Best-known AUTHORITATIVE classification: Base's own empirical preflight
    first, then the Main handoff dispatch context. WebHelper/EventID 301 is
    never consulted here - it is corroboration, not classification.
    #>
    param($PreflightObservation = $null, $DispatchContext = $null)

    if ($PreflightObservation -and $PreflightObservation.redirect_type) {
        return [string]$PreflightObservation.redirect_type
    }
    if ($DispatchContext -and $DispatchContext.redirect_type) {
        return [string]$DispatchContext.redirect_type
    }
    return ""
}

function Get-BaseCapMissingNavigationOutcome {
    <#
    .SYNOPSIS
    Classifies the ABSENCE of a Cisco WebHelper EventID 301 navigation.

    .DESCRIPTION
    EventID 301 / WebView2 is optional corroboration. A missing 301 is the
    NORMAL case for an on-prem ISE posture redirect (ISE_EMPLOYEE), where no
    WebView2 captive-portal navigation ever happens, so it is recorded as
    not_applicable / no_event_301 at INFO rather than as a warning - and it
    never changes the authoritative preflight classification or the rescan
    decision, which belong to Main.
    #>
    param(
        [string]$RedirectType = "",
        [string]$WebHelperError = "",
        [string]$DefaultReason = "no_event_301"
    )

    if ($RedirectType -eq 'ISE_EMPLOYEE') {
        return [PSCustomObject]@{
            Outcome = 'not_applicable'
            Reason  = 'not_applicable_ise_employee_no_event_301'
            Level   = 'INFO'
        }
    }

    $reason = if ($WebHelperError) { $WebHelperError } else { $DefaultReason }
    return [PSCustomObject]@{ Outcome = 'not_observed'; Reason = $reason; Level = 'WARN' }
}

function Write-BaseCapPreflightFinding {
    <#
    Renders a preflight observation in the same readable style Main uses in
    white_walker.main.log ("nwcheck: REDIRECT to <url>" / "Redirect
    classification: <type>"). Observation only - Base never remediates.
    #>
    param([Parameter(Mandatory)]$Observation)

    if ($Observation.status -eq 'redirect') {
        Write-BaseCapLog "nwcheck: REDIRECT to $($Observation.redirect_url)" "INFO"
        Write-BaseCapLog "Redirect classification: $($Observation.redirect_type)" "INFO"
        Write-BaseCapLog "Redirect details: protocol=$($Observation.protocol) fqdn=$($Observation.fqdn) port=$($Observation.port) http_status=$($Observation.http_status) reason=$($Observation.reason)" "INFO"
        Write-BaseCapLog "Base observer: redirect recorded for evidence only - no browser launch, no process kill, no VPN change, no posture rescan" "INFO"
    } elseif ($Observation.status -eq 'online') {
        Write-BaseCapLog "nwcheck: ONLINE (http_status='$($Observation.http_status)' reason='$($Observation.reason)') - no captive portal action" "INFO"
    } else {
        $detail = if ($Observation.error_message) { $Observation.error_message } else { $Observation.reason }
        Write-BaseCapLog "nwcheck: $($Observation.status.ToUpper()) (classification='$($Observation.classification)' http_status='$($Observation.http_status)' reason='$($Observation.reason)' detail='$detail') - inconclusive, not proof of a clean network" "WARN"
    }
}

function Write-BaseCapPreflightTelemetry {
    param(
        [Parameter(Mandatory)]$Observation,
        [hashtable]$NetworkContext = @{},
        [string]$VpnState = ""
    )
    try {
        $null = Write-BaseCapTee -Tag 'cap_portal_preflight_observation' -Data @{
            EvtTime = $Observation.observation_time; probe_url = $Observation.probe_url
            status = $Observation.status; http_status = $Observation.http_status
            redirect_url = $Observation.redirect_url; redirect_type = [string]$Observation.redirect_type
            classification = [string]$Observation.classification
            protocol = $Observation.protocol
            fqdn = $Observation.fqdn; port = $Observation.port; duration_ms = [string]$Observation.duration_ms
            attempt = [string]$Observation.attempt
            reason = $Observation.reason; ssid = [string]$NetworkContext.ssid
            ip = [string]$NetworkContext.ip; gw = [string]$NetworkContext.gw
            dns = [string]$NetworkContext.dns; vpn_state = $VpnState
        }
    } catch {
        Write-BaseCapLog "Failed to ship cap_portal_preflight_observation telemetry: $_" "WARN"
    }
}

function Write-BaseCapRunnerLifecycleTelemetry {
    <#
    .SYNOPSIS
    Runner-lifecycle telemetry so a FlareGun dispatch can be correlated end to
    end in Splunk: flare_dispatched -> flare_runner_started -> preflight
    observation -> webhelper navigation -> flare_runner_completed.
    Fail-soft: never breaks or delays the observer.
    #>
    param(
        [ValidateSet('flare_runner_started', 'flare_runner_completed')]
        [string]$Action = 'flare_runner_started',
        [string]$Status = "",
        [string]$Reason = "",
        [hashtable]$NetworkContext = @{},
        [string]$VpnState = "",
        [string]$DurationSec = ""
    )

    try {
        $null = Write-BaseCapTee -Tag $Action -Data @{
            EvtTime     = (Get-Date -Format 'o')
            runner      = 'WW_cap_portal_runner_base'
            flare_tag   = 'captive_portal_browser_base'
            event_id    = '778'
            context     = 'USER'
            status      = $Status
            reason      = $Reason
            duration_sec = $DurationSec
            ssid        = [string]$NetworkContext.ssid
            ip          = [string]$NetworkContext.ip
            gw          = [string]$NetworkContext.gw
            dns         = [string]$NetworkContext.dns
            vpn_state   = $VpnState
        }
    } catch {
        Write-BaseCapLog "Failed to ship $Action telemetry: $_" "WARN"
    }
}

function Write-BaseCapWebHelperTelemetry {
    param(
        [Parameter(Mandatory)]$Navigation,
        [hashtable]$NetworkContext = @{},
        [string]$VpnState = "",
        [string]$Outcome = "observed",
        [string]$Reason = ""
    )
    try {
        $urlDetails = Get-BaseCapUrlDetails -Url ([string]$Navigation.NavigatedUrl)
        $navigationClassification = if (-not $urlDetails.url) { '' } elseif ($urlDetails.fqdn -match '(?i)isepsn') {
            'ISE_EMPLOYEE'
        } elseif ($urlDetails.fqdn -match '(?i)isegst') { 'ISE_GUEST' } else { 'NON_ISE' }
        $null = Write-BaseCapTee -Tag 'cap_portal_webhelper_navigation' -Data @{
            EvtTime = if ($Navigation.EventTime) { $Navigation.EventTime.ToString('o') } else { (Get-Date -Format 'o') }
            detection_source = 'cisco_webhelper_301'
            navigated_url = [string]$Navigation.NavigatedUrl; final_url = [string]$Navigation.FinalUrl
            final_url_port = [string]$Navigation.FinalUrlPort; process_id = [string]$Navigation.ProcessId
            thread_id = [string]$Navigation.ThreadId; ap_name = [string]$Navigation.ApName
            ap_tags = [string]$Navigation.ApTags; ap_mac = [string]$Navigation.ApMac
            sip = [string]$Navigation.Sip; org = [string]$Navigation.Org; ui = [string]$Navigation.Ui
            psid = [string]$Navigation.Psid; login_url = [string]$Navigation.LoginUrl
            ma = [string]$Navigation.Ma; os = [string]$Navigation.Os; api_domain = [string]$Navigation.ApiDomain
            os_name = [string]$Navigation.OsName; os_version = [string]$Navigation.OsVersion
            browser_name = [string]$Navigation.BrowserName; browser_version = [string]$Navigation.BrowserVersion
            device_type = [string]$Navigation.DeviceType; trace_id = [string]$Navigation.TraceId
            event_record_id = [string]$Navigation.EventRecordId
            event_source = 'Cisco Secure Client EventID 301'; event_time = if ($Navigation.EventTime) { $Navigation.EventTime.ToString('o') } else { '' }
            classification = $navigationClassification; protocol = [string]$urlDetails.protocol
            fqdn = [string]$urlDetails.fqdn; port = [string]$urlDetails.port
            status = $Outcome; reason = $Reason; ssid = [string]$NetworkContext.ssid
            ip = [string]$NetworkContext.ip; gw = [string]$NetworkContext.gw
            dns = [string]$NetworkContext.dns; vpn_state = $VpnState
        }
    } catch {
        Write-BaseCapLog "Failed to ship cap_portal_webhelper_navigation telemetry: $_" "WARN"
    }
}
function Test-VPNBlockingNetwork { return $false }
function Invoke-BaseCapVpnDisconnect { return $false }
function Get-BaseNativePortalProcesses { return @() }

function Write-CaptivePortalEventToHayStack {
    <#
    .SYNOPSIS
    LEGACY HayStack queue event (action="network_state_change").

    .DESCRIPTION
    Preserved for the existing Splunk views/alerts that already key off
    network_state_change. This is NOT a normalized cap_portal_* outcome row -
    it carries no user/EvtTime/ssid/vpn_state - so RC1.25 stamps
    event_class="legacy_haystack" on it to make the distinction explicit and
    prevent a legacy row being read as a normalized remediation outcome.
    Normalized outcomes are shipped separately via Write-BaseCapOutcomeTelemetry.
    #>
    param(
        [string]$IP,
        [string]$FQDN,
        [string]$Protocol,
        [int]$Port
    )

    try {
        $payload = "action=`"network_state_change`" event_class=`"legacy_haystack`" machine=`"$env:COMPUTERNAME`" ts=`"$((Get-Date).ToString('o'))`" reason=`"captive_portal_detected`" ip=`"$IP`" fqdn=`"$FQDN`" protocol=`"$Protocol`" port=`"$Port`""
        $entry = @{
            ts        = (Get-Date).ToString("o")
            payload   = $payload
            extraInfo = ""
        } | ConvertTo-Json -Compress

        if (Get-Command Add-TeeQueueEntry -ErrorAction SilentlyContinue) {
            $queueWrite = Add-TeeQueueEntry -Path $SyslogQueueFile -Entry $entry
            if ($queueWrite.Queued) {
                Write-BaseCapLog "Queued LEGACY captive portal event to HayStack syslog queue (reason=queued): $payload" "INFO"
            } else {
                Write-BaseCapLog "Failed to queue LEGACY captive portal event to HayStack (reason=$($queueWrite.Reason) queue=$SyslogQueueFile): $($queueWrite.Error)" "WARN"
            }
        } else {
            Add-Content -Path $SyslogQueueFile -Value $entry -Encoding UTF8 -ErrorAction Stop
            Write-BaseCapLog "Queued LEGACY captive portal event to HayStack syslog queue (reason=queued): $payload" "INFO"
        }
    } catch {
        $reasonToken = if ($_.Exception -is [System.UnauthorizedAccessException] -or "$_" -match 'is denied') { 'access_denied' } else { 'error' }
        Write-BaseCapLog "Failed to queue captive portal event to HayStack (reason=$reasonToken): $_" "WARN"
    }
}

function Get-BaseCapNetworkContext {
    <#
    .SYNOPSIS
    Gathers this process's own best-available network context (ssid/ip/gw/dns).

    .DESCRIPTION
    RC1.25: the base runner is launched by Task Scheduler as its own process and
    can never see WW_main.ps1's $networkInfo. Previously it emitted nothing for
    ip/gw/dns/ssid, which is why base-mode rows in Splunk were empty. It now
    queries the OS directly. Anything that cannot be determined stays an explicit
    empty string (with the reason logged) - never a fabricated value.
    #>
    $ctx = @{
        captured_at = (Get-Date).ToString('o'); ssid = ''; ip = ''; prefix = ''
        gw = ''; dns = ''; mac = ''; interface_index = ''; interface_guid = ''
        interface_name = ''; adapter_class = 'unknown'; operational_state = ''
        fingerprint = ''
    }
    $adapterDiscoveryStartedAt = Get-Date
    $routeMs = 0
    $adapterMs = 0
    $ipMs = 0
    $dnsMs = 0

    try {
        $stepStartedAt = Get-Date
        $routes = @(Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction Stop |
            Sort-Object @{ Expression = { [int]$_.RouteMetric + [int]$_.InterfaceMetric } })
        $routeMs = ((Get-Date) - $stepStartedAt).TotalMilliseconds
        foreach ($route in $routes) {
            $stepStartedAt = Get-Date
            $adapter = Get-NetAdapter -InterfaceIndex $route.InterfaceIndex -ErrorAction SilentlyContinue
            $adapterMs += ((Get-Date) - $stepStartedAt).TotalMilliseconds
            if (-not $adapter -or $adapter.Status -ne 'Up') { continue }
            $identity = "$($adapter.Name) $($adapter.InterfaceDescription) $($adapter.MediaType) $($adapter.NdisPhysicalMedium)"
            if ($adapter.Virtual -eq $true -or $identity -match '(?i)Cisco|AnyConnect|VPN|Secure Client|TAP|Tunnel|Virtual|WAN Miniport') { continue }

            $ctx.interface_index = [string]$adapter.InterfaceIndex
            $ctx.interface_guid = [string]$adapter.InterfaceGuid
            $ctx.interface_name = [string]$adapter.Name
            $ctx.operational_state = [string]$adapter.Status
            $ctx.mac = [string]$adapter.MacAddress
            if ($identity -match '(?i)Wi-?Fi|Wireless|802\.11|Native 802\.11') { $ctx.adapter_class = 'wifi' }
            elseif ($identity -match '(?i)Ethernet|802\.3|\bLAN\b') { $ctx.adapter_class = 'ethernet' }

            $stepStartedAt = Get-Date
            $address = Get-NetIPAddress -InterfaceIndex $adapter.InterfaceIndex -AddressFamily IPv4 `
                -ErrorAction SilentlyContinue | Where-Object {
                    $_.IPAddress -and $_.IPAddress -notmatch '^127\.'
                } | Select-Object -First 1
            $ipMs += ((Get-Date) - $stepStartedAt).TotalMilliseconds
            if ($address) {
                $ctx.ip = [string]$address.IPAddress
                $ctx.prefix = [string]$address.PrefixLength
            }
            $ctx.gw = [string]$route.NextHop

            $stepStartedAt = Get-Date
            $dns = Get-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex `
                -AddressFamily IPv4 -ErrorAction SilentlyContinue
            $dnsMs += ((Get-Date) - $stepStartedAt).TotalMilliseconds
            if ($dns -and $dns.ServerAddresses) { $ctx.dns = (@($dns.ServerAddresses) -join ',') }
            break
        }
        if ([string]::IsNullOrWhiteSpace($ctx.interface_index)) {
            Write-BaseCapLog "No active non-VPN adapter with a default gateway found - ip/gw/dns left empty" "WARN"
        }
    } catch {
        Write-BaseCapLog "Could not read local IP configuration: $_ - ip/gw/dns left empty" "WARN"
    }
    $adapterDiscoveryMs = [math]::Round(((Get-Date) - $adapterDiscoveryStartedAt).TotalMilliseconds)

    $ssidDiscoveryStartedAt = Get-Date
    if ($ctx.adapter_class -eq 'wifi') {
        try {
            $wlan = & netsh.exe wlan show interfaces 2>$null | Out-String
            if ($wlan) {
                $ssidMatch = [regex]::Match($wlan, '(?im)^\s*SSID\s*:\s*(.+?)\s*$')
                if ($ssidMatch.Success) { $ctx.ssid = $ssidMatch.Groups[1].Value.Trim() }
            }
            if ([string]::IsNullOrWhiteSpace($ctx.ssid)) {
                Write-BaseCapLog "No wireless SSID reported by netsh - ssid left empty" "DEBUG"
            }
        } catch {
            Write-BaseCapLog "Could not read SSID via netsh: $_ - ssid left empty" "DEBUG"
        }
    } else {
        Write-BaseCapLog "SSID not applicable to selected adapter_class='$($ctx.adapter_class)'" "DEBUG"
    }
    $ctx.fingerprint = (@($ctx.interface_index, $ctx.interface_guid, $ctx.ip, $ctx.gw, $ctx.ssid, $ctx.operational_state) -join '|').ToLowerInvariant()
    Write-BaseCapLog ("phase_timing phase='base_network_context_discovery' adapter_ip_gateway_ms={0} ssid_discovery_ms={1} route_ms={2} adapter_ms={3} ip_address_ms={4} dns_ms={5}" -f `
        $adapterDiscoveryMs, [math]::Round(((Get-Date) - $ssidDiscoveryStartedAt).TotalMilliseconds), `
        [math]::Round($routeMs), [math]::Round($adapterMs), [math]::Round($ipMs), [math]::Round($dnsMs)) "INFO"

    return $ctx
}

function Write-CompletionFlag {
    param(
        [string]$Status,
        [string]$Details = "",
        [int]$CaptiveBrowserPID = 0,
        $PreflightObservation = $null,
        $WebHelperNavigation = $null
    )

    $flagData = @{
        timestamp = (Get-Date).ToString('o')
        status = $Status
        details = $Details
        user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        captive_browser_pid = $CaptiveBrowserPID
        base_preflight_observation = $PreflightObservation
        base_webhelper_navigation = $WebHelperNavigation
    }
    $flagContent = $flagData | ConvertTo-Json -Compress

    try {
        $tempFlag = "$FlagFile.$PID.tmp"
        Set-Content -Path $tempFlag -Value $flagContent -Encoding UTF8 -ErrorAction Stop
        Move-Item -Path $tempFlag -Destination $FlagFile -Force -ErrorAction Stop
        Write-BaseCapLog "Completion flag written: $Status (PID: $CaptiveBrowserPID)" "INFO"
    } catch {
        Write-BaseCapLog "Failed to write completion flag: $_" "ERROR"
    }
}

function Test-SiteReachability {
    param([string]$Url = $ValidationSite, [int]$TimeoutSec = $BaseSiteTimeoutSec)

    Write-BaseCapLog "Testing site reachability silently: $Url" "DEBUG"

    try {
        # CRITICAL: 3s timeout ensures completion within polling interval (prevents hang)
        $response = Invoke-WebRequest -Uri $Url -TimeoutSec $TimeoutSec -UseBasicParsing -ErrorAction Stop
        if ($response.StatusCode -eq 200) {
            Write-BaseCapLog "Site validation successful: $Url (HTTP $($response.StatusCode))" "INFO"
            return $true
        } else {
            Write-BaseCapLog "Site validation failed: $Url (HTTP $($response.StatusCode))" "WARN"
            return $false
        }
    } catch {
        Write-BaseCapLog "Site validation failed: $Url - $($_.Exception.Message)" "DEBUG"
        return $false
    }
}

function Get-VpnStateQuick {
    try {
        if (-not (Test-Path $VpnCliPath)) {
            Write-BaseCapLog "vpncli not found at expected path: $VpnCliPath" "DEBUG"
            return "Unknown"
        }

        $stateOutput = & $VpnCliPath status 2>$null | Out-String
        if (-not $stateOutput) {
            return "Unknown"
        }

        $stateMatches = [regex]::Matches($stateOutput, '(?im)^\s*>>\s*state:\s*(\w+)\s*$')
        if ($stateMatches.Count -gt 0) {
            return $stateMatches[$stateMatches.Count - 1].Groups[1].Value
        }

        return "Unknown"
    } catch {
        Write-BaseCapLog "Get-VpnStateQuick error: $_" "DEBUG"
        return "Unknown"
    }
}

function Write-BaseCapOutcomeTelemetry {
    <#
    .SYNOPSIS
    Ships normalized cap_portal_remediation_passed / cap_portal_remediation_failed
    via Write-TeeLog, with the exact flat field set WW_main.ps1's
    Write-CaptivePortalOutcomeTelemetry uses for full-mode runs:
    EvtTime, action, machine, user, ssid, url, port, ip, gw, dns, vpn_state,
    portal_type, status, reason.

    RC1.25: ip/gw/dns/ssid are gathered by THIS process (Get-BaseCapNetworkContext)
    because the base runner never shares scope with WW_main.ps1. Any field that
    cannot be determined is emitted empty, never invented.
    #>
    param(
        [Parameter(Mandatory)][ValidateSet('cap_portal_remediation_passed', 'cap_portal_remediation_failed')]
        [string]$Action,
        [string]$Url = "",
        [string]$Port = "",
        [string]$PortalType = "",
        [string]$Status = "",
        [string]$Reason = "",
        [string]$Ssid = "",
        [string]$VpnState = "",
        [string]$Ip = "",
        [string]$Gw = "",
        [string]$Dns = ""
    )

    try {
        $null = Write-BaseCapTee -Tag $Action -Data @{
            EvtTime     = (Get-Date -Format 'o')
            url         = $Url
            port        = $Port
            portal_type = $PortalType
            status      = $Status
            reason      = $Reason
            ssid        = $Ssid
            vpn_state   = $VpnState
            ip          = $Ip
            gw          = $Gw
            dns         = $Dns
        }
    } catch {
        Write-BaseCapLog "Failed to ship $Action telemetry via Write-TeeLog: $_" "WARN"
    }
}

function Get-BaseCapTelemetryUrl {
    <#
    .SYNOPSIS
    CANONICAL captive-portal URL selection, in strict precedence order:

      1. authoritative preflight redirect (Main's or Base's empirical
         gateway.optum.com result)
      2. the original Main handoff context (dispatch_context.redirect_url)
      3. Cisco WebHelper navigated_url - CORROBORATING evidence only, used
         solely when no preflight redirect is available
      4. remediation-state url, then protocol+fqdn (gateway fallback)

    WebHelper final_url (typically http://www.msftconnecttest.com/connecttest.txt)
    is NEVER a candidate - it is the connectivity probe Cisco ended on, not the
    captive portal. The selected source is always logged.
    #>
    param(
        [string]$Url = "",
        [string]$Protocol = "",
        [string]$Fqdn = "",
        [string]$WebHelperNavigatedUrl = "",
        [string]$PreflightRedirectUrl = "",
        [string]$MainHandoffRedirectUrl = ""
    )

    $placeholder = @('unknown', 'n/a', 'none')
    $isUsable = {
        param([string]$Candidate)
        (-not [string]::IsNullOrWhiteSpace($Candidate)) -and ($placeholder -notcontains $Candidate.ToLowerInvariant())
    }

    if (& $isUsable $PreflightRedirectUrl) {
        Write-BaseCapLog "Canonical outcome URL source=authoritative_preflight_redirect url='$PreflightRedirectUrl'" "INFO"
        return $PreflightRedirectUrl
    }
    if (& $isUsable $MainHandoffRedirectUrl) {
        Write-BaseCapLog "Canonical outcome URL source=main_handoff_context url='$MainHandoffRedirectUrl'" "INFO"
        return $MainHandoffRedirectUrl
    }
    if (& $isUsable $WebHelperNavigatedUrl) {
        Write-BaseCapLog "Canonical outcome URL source=webhelper_navigated_url (corroborating evidence - no preflight redirect available) url='$WebHelperNavigatedUrl'" "INFO"
        return $WebHelperNavigatedUrl
    }
    if (& $isUsable $Url) {
        Write-BaseCapLog "Canonical outcome URL source=remediation_state url='$Url'" "INFO"
        return $Url
    }

    if ((& $isUsable $Protocol) -and (& $isUsable $Fqdn)) {
        Write-BaseCapLog "Canonical outcome URL source=remediation_state_gateway_fallback" "INFO"
        return "${Protocol}://${Fqdn}"
    }

    Write-BaseCapLog "Portal URL unavailable from preflight, handoff, WebHelper or remediation state - url emitted empty" "WARN"
    return ""
}

function Write-BaseCapAtomicFile {
    <#
    Atomic temp+move write (Required F/G). The reader is a different security
    context and a different process, so a partially written artifact must never
    be observable. Fail-soft: returns $false instead of throwing.
    #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Content
    )

    try {
        $dir = Split-Path -Path $Path -Parent
        if ($dir -and -not (Test-Path $dir)) {
            New-Item -Path $dir -ItemType Directory -Force -ErrorAction Stop | Out-Null
        }
        $temp = "$Path.$([guid]::NewGuid().ToString('N')).tmp"
        [System.IO.File]::WriteAllText($temp, $Content, (New-Object System.Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $temp -Destination $Path -Force -ErrorAction Stop
        return $true
    } catch {
        Write-BaseCapLog "Atomic write failed for $Path : $_" "DEBUG"
        try { if ($temp -and (Test-Path $temp)) { Remove-Item $temp -Force -ErrorAction SilentlyContinue } } catch { }
        return $false
    }
}

function Write-BaseCapPreflightHandback {
    <#
    .SYNOPSIS
    Preserves the best known AUTHORITATIVE preflight context in the remediation
    state artifact before Base escalates to Event 777.

    .DESCRIPTION
    Without this, the full runner restarts with only the original (possibly
    inconclusive) Main context and can blindly open http://enroll.cisco.com
    even though Base empirically observed a real portal redirect. Fail-soft:
    a write failure never stops the escalation.
    #>
    param(
        [Parameter(Mandatory)]$Observation,
        $DispatchContext = $null
    )

    try {
        $state = @{}
        if (Test-Path $RemediationStateFile) {
            try {
                $existing = Get-Content -Path $RemediationStateFile -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                foreach ($property in $existing.PSObject.Properties) { $state[$property.Name] = $property.Value }
            } catch {
                Write-BaseCapLog "Could not re-read remediation state before escalation: $_" "DEBUG"
            }
        }

        $state['base_preflight_observation'] = $Observation
        $state['base_preflight_updated'] = (Get-Date).ToString('o')
        if ($DispatchContext) { $state['dispatch_context'] = $DispatchContext }

        if ($Observation.status -eq 'redirect' -and $Observation.redirect_url) {
            # Authoritative empirical redirect wins over the handoff placeholder.
            $state['url'] = [string]$Observation.redirect_url
            $state['protocol'] = [string]$Observation.protocol
            $state['fqdn'] = [string]$Observation.fqdn
            $state['port'] = [string]$Observation.port
            $state['redirect_type'] = [string]$Observation.redirect_type
            $state['portal_type'] = [string]$Observation.redirect_type
            $state['url_source'] = 'base_authoritative_preflight_redirect'
            Write-BaseCapLog "Escalation handback: preserved authoritative preflight redirect url='$($Observation.redirect_url)' classification='$($Observation.redirect_type)'" "INFO"
        } else {
            $state['url_source'] = 'main_handoff_context'
            Write-BaseCapLog "Escalation handback: no usable Base preflight redirect - preserving Main handoff context (reason='$($Observation.reason)')" "WARN"
        }

        $json = $state | ConvertTo-Json -Compress -Depth 4

        # 1. ALWAYS write the user-result artifact Main consumes. Atomic
        #    temp+move so a SYSTEM reader never sees a partial file.
        $handbackWritten = Write-BaseCapAtomicFile -Path $BaseHandbackFile -Content $json
        if ($handbackWritten) {
            Write-BaseCapLog "Base handback artifact written: $BaseHandbackFile" "INFO"
        } else {
            Write-BaseCapLog "Could not write Base handback artifact: $BaseHandbackFile" "WARN"
        }

        # 2. Opportunistically refresh the SYSTEM-owned artifact. Access denied
        #    here is EXPECTED in USER context and is not an error - the handback
        #    above already carries the evidence.
        try {
            Set-Content -Path $RemediationStateFile -Value $json -Encoding UTF8 -ErrorAction Stop
        } catch {
            Write-BaseCapLog "SYSTEM-owned remediation artifact not writable from user context (expected): $_ - evidence preserved in the Base handback artifact instead" "INFO"
        }
    } catch {
        Write-BaseCapLog "Could not preserve preflight context before escalation: $_" "WARN"
    }
}

function Get-BaseCapVpnState {
    <#
    .SYNOPSIS
    Cached VPN state - at most ONE vpncli.exe invocation per observe cycle.

    .DESCRIPTION
    RC2.1 (Required D). Base used to call Get-VpnStateQuick inline around every
    telemetry call, which shelled vpncli.exe many times per cycle and delayed the
    first empirical preflight. The value is now read once per cycle and passed to
    every log/telemetry consumer. -Force refreshes it explicitly.
    #>
    param([switch]$Force)

    if ($Force -or -not $script:BaseVpnStateCached) {
        $script:BaseVpnState = Get-VpnStateQuick
        $script:BaseVpnStateCached = $true
    }
    return $script:BaseVpnState
}

function Reset-BaseCapVpnStateCache {
    $script:BaseVpnStateCached = $false
}

function Test-BaseLocalNetworkReady {
    <#
    .SYNOPSIS
    Fast, strict re-check of the local network at Base startup (Required B).

    .DESCRIPTION
    Mirrors Main.Network.ps1:Test-PlausibleLocalNetwork. The network can
    disappear between Main's dispatch and Base's launch; when it has, Base must
    exit in seconds rather than burning the whole observation window probing a
    dead stack - and it must never escalate.

    Requires a usable IPv4 (not empty/APIPA/loopback/0.0.0.0) AND a valid
    non-zero default gateway. A Wi-Fi path additionally needs a currently
    connected SSID; a wired path legitimately has none, which is why an empty
    SSID combined with a valid adapter/IP/gateway is accepted.
    #>
    param([hashtable]$NetworkContext = @{}, [string]$ConnectionType = "")

    $result = @{ Ready = $false; Reason = 'no_network_context' }

    $ip = [string]$NetworkContext.ip
    $gw = [string]$NetworkContext.gw
    $ssid = [string]$NetworkContext.ssid

    if ([string]::IsNullOrWhiteSpace($ip)) { $result.Reason = 'no_ip'; return $result }
    if ($ip -like '169.254.*')             { $result.Reason = 'apipa_ip'; return $result }
    if ($ip -like '127.*' -or $ip -eq '0.0.0.0') { $result.Reason = 'invalid_ip'; return $result }
    if ([string]::IsNullOrWhiteSpace($gw) -or $gw -eq '0.0.0.0' -or $gw -eq 'N/A') {
        $result.Reason = 'no_default_gateway'; return $result
    }
    if ($ConnectionType -eq 'WiFi' -and [string]::IsNullOrWhiteSpace($ssid)) {
        $result.Reason = 'wifi_no_connected_ssid'; return $result
    }

    $result.Ready = $true
    $result.Reason = 'valid_ip_and_gateway'
    return $result
}

function Test-BaseHandoffArtifact {
    <#
    .SYNOPSIS
    Decides whether a Main handoff artifact still describes the live network.

    .DESCRIPTION
    RC2.1 (Required F). The endpoint showed Base reading
    "portal_type=suspected gateway_ip=10.10.69.1 ssid=cia_van" while the live
    context was ssid='xfinitywifi' ip='172.20.20.20' gw='172.20.20.1'. An
    artifact is rejected when:

      stale_handoff             - created_at/timestamp older than MaxAgeSeconds
      network_context_mismatch  - its network identity conflicts with live
                                  context (SSID for Wi-Fi; otherwise
                                  adapter/IP/gateway identity)

    Missing timestamps or missing identity fields are NOT treated as a conflict
    (nothing to contradict) - only a populated, differing value is.
    #>
    param(
        $StateData,
        [hashtable]$NetworkContext = @{},
        [int]$MaxAgeSeconds = 900
    )

    $result = @{ Accepted = $true; Reason = 'accepted'; AgeSeconds = -1 }
    if ($null -eq $StateData) { $result.Accepted = $false; $result.Reason = 'no_handoff_artifact'; return $result }

    $created = $null
    foreach ($field in @('created_at', 'timestamp')) {
        $value = [string]$StateData.$field
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            try { $created = [datetime]::Parse($value, [cultureinfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::RoundtripKind); break } catch { }
        }
    }
    if ($created) {
        $result.AgeSeconds = [math]::Round(((Get-Date) - $created).TotalSeconds)
        if ($result.AgeSeconds -gt $MaxAgeSeconds) {
            $result.Accepted = $false
            $result.Reason = 'stale_handoff'
            return $result
        }
    }

    $handoffSsid = [string]$StateData.ssid
    $liveSsid    = [string]$NetworkContext.ssid
    if (-not [string]::IsNullOrWhiteSpace($liveSsid) -and -not [string]::IsNullOrWhiteSpace($handoffSsid) -and
        $handoffSsid -ne 'N/A' -and $liveSsid -ne $handoffSsid) {
        $result.Accepted = $false
        $result.Reason = 'network_context_mismatch'
        return $result
    }

    if ([string]::IsNullOrWhiteSpace($liveSsid)) {
        # Wired (or radio off): fall back to adapter/IP/gateway identity.
        foreach ($pair in @(@('ip', [string]$NetworkContext.ip), @('gw', [string]$NetworkContext.gw))) {
            $handoffValue = [string]$StateData.($pair[0])
            $liveValue    = [string]$pair[1]
            if (-not [string]::IsNullOrWhiteSpace($liveValue) -and -not [string]::IsNullOrWhiteSpace($handoffValue) -and
                $handoffValue -ne 'N/A' -and $handoffValue -ne $liveValue) {
                $result.Accepted = $false
                $result.Reason = 'network_context_mismatch'
                return $result
            }
        }
    }

    return $result
}

function Resolve-BaseEscalationPolicy {
    <#
    .SYNOPSIS
    Effective Base -> Full (Event 777) escalation policy (Required A).

    .DESCRIPTION
    Base is standalone and cannot see Main's $CapPortalBaseAllowFullEscalation,
    so Main writes it into the dispatch artifact as base_allow_full_escalation.
    A missing, undefined, unparsable or rejected artifact FAILS SAFE to $false:
    no Event 777, no full-runner launch.
    #>
    param($StateData, [bool]$Default = $false)

    $resolved = @{ Allowed = $Default; Source = 'default_fail_safe' }
    if ($null -eq $StateData) { return $resolved }

    $property = $StateData.PSObject.Properties['base_allow_full_escalation']
    if ($null -eq $property -or $null -eq $property.Value) { return $resolved }

    $raw = [string]$property.Value
    if ([string]::IsNullOrWhiteSpace($raw)) { return $resolved }

    $parsed = $false
    if ([bool]::TryParse($raw, [ref]$parsed)) {
        $resolved.Allowed = $parsed
        $resolved.Source = 'dispatch_artifact'
    }
    return $resolved
}

function Read-BaseDispatchArtifact {
    <#
    Reads the Main -> runner dispatch artifact ONCE, purely for configuration
    (Required E). Handoff ACCEPTANCE (staleness / network-identity match) is a
    separate decision made later by Test-BaseHandoffArtifact; a rejected handoff
    still never supplies portal context. Fail-soft: returns $null.
    #>
    try {
        if (-not (Test-Path $RemediationStateFile)) { return $null }
        return (Get-Content -Path $RemediationStateFile -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop)
    } catch {
        return $null
    }
}

function Get-CprTimingValue {
    <#
    Reads one value from Main's timing_contract. A sane positive value wins;
    anything missing/garbage falls back to this script's fail-safe literal.
    #>
    param($Contract, [string]$Key, $Fallback, [int]$Maximum = 3600)

    if ($null -eq $Contract) { return $Fallback }

    # RC2.2 (Required B): the contract can arrive as a PSCustomObject (parsed
    # artifact JSON), a hashtable or an [ordered]@{} - and an OrderedDictionary
    # has Contains(), NOT ContainsKey(). Handle all three shapes here so no
    # caller has to type-check.
    $raw = $null
    try {
        if ($Contract -is [System.Collections.IDictionary]) {
            if (-not $Contract.Contains($Key)) { return $Fallback }
            $raw = $Contract[$Key]
        }
        else {
            if (-not (@($Contract.PSObject.Properties.Name) -contains $Key)) { return $Fallback }
            $raw = $Contract.$Key
        }
    } catch { return $Fallback }
    if ($null -eq $raw) { return $Fallback }
    if ($Fallback -is [string]) {
        $text = [string]$raw
        if ([string]::IsNullOrWhiteSpace($text)) { return $Fallback }
        return $text
    }
    $value = 0
    if ([int]::TryParse([string]$raw, [ref]$value) -and $value -gt 0 -and $value -le $Maximum) { return $value }
    return $Fallback
}

function Get-CprBehaviorValue {
    param($Contract, [string]$Key, [bool]$Fallback)
    if ($null -eq $Contract) { return $Fallback }
    try {
        if (-not (@($Contract.PSObject.Properties.Name) -contains $Key)) { return $Fallback }
        $raw = $Contract.$Key
        if ($raw -is [bool]) { return [bool]$raw }
        if ([string]$raw -match '^(?i:true|false)$') { return [System.Convert]::ToBoolean([string]$raw) }
    } catch { }
    return $Fallback
}

function Resolve-BaseTimingContract {
    <#
    Effective Base timers/behavior for this run (Required E). Source is
    'dispatch_artifact' when Main's timing_contract is present and usable,
    otherwise 'fallback_defaults' (manual/legacy launch).
    #>
    param($StateData)

    $contract = $null
    if ($null -ne $StateData) {
        try {
            if (@($StateData.PSObject.Properties.Name) -contains 'timing_contract') { $contract = $StateData.timing_contract }
        } catch { $contract = $null }
    }

    return @{
        Source                      = $(if ($contract) { 'dispatch_artifact' } else { 'fallback_defaults' })
        ObserveTimeoutSeconds       = (Get-CprTimingValue -Contract $contract -Key 'base_observe_timeout_sec'       -Fallback $ObserveTimeoutSeconds)
        CheckIntervalSec            = (Get-CprTimingValue -Contract $contract -Key 'base_check_interval_sec'        -Fallback $CheckIntervalSec -Maximum 300)
        PreflightTimeoutMs          = (Get-CprTimingValue -Contract $contract -Key 'base_preflight_timeout_ms'      -Fallback $BasePreflightTimeoutMs -Maximum 60000)
        PreflightMaxProbes          = (Get-CprTimingValue -Contract $contract -Key 'base_preflight_max_probes'      -Fallback $BasePreflightMaxProbes -Maximum 100)
        WebHelperLookbackSeconds    = (Get-CprTimingValue -Contract $contract -Key 'base_webhelper_lookback_sec'    -Fallback $CiscoWebHelperLookbackSeconds)
        MaxHandoffAgeSeconds        = (Get-CprTimingValue -Contract $contract -Key 'handoff_max_age_sec'            -Fallback $MaxHandoffAgeSeconds -Maximum 86400)
        ValidationSite              = (Get-CprTimingValue -Contract $contract -Key 'validation_site'                -Fallback $ValidationSite)
        SiteTimeoutSec              = (Get-CprTimingValue -Contract $contract -Key 'site_reachability_timeout_sec'  -Fallback $BaseSiteTimeoutSec -Maximum 120)
        PreflightUrl                = (Get-CprTimingValue -Contract $contract -Key 'preflight_url'                  -Fallback $BasePreflightUrl)
        NetworkReadyMaxWaitMs       = (Get-CprTimingValue -Contract $contract -Key 'network_ready_max_wait_ms'      -Fallback $BaseNetworkReadyMaxWaitMs -Maximum 120000)
        NetworkReadyPollIntervalMs  = (Get-CprTimingValue -Contract $contract -Key 'network_ready_poll_interval_ms' -Fallback $BaseNetworkReadyPollIntervalMs -Maximum 60000)
        NetworkReadyGatewayTimeoutMs = (Get-CprTimingValue -Contract $contract -Key 'network_ready_gateway_timeout_ms' -Fallback $BaseNetworkReadyGatewayTimeoutMs -Maximum 60000)
        NetworkReadyDnsTimeoutMs    = (Get-CprTimingValue -Contract $contract -Key 'network_ready_dns_timeout_ms'   -Fallback $BaseNetworkReadyDnsTimeoutMs -Maximum 60000)
        SuppressPreflightForWebHelper301 = (Get-CprBehaviorValue -Contract $contract -Key 'webhelper_301_suppress_preflight' -Fallback $BaseWebHelper301SuppressPreflight)
        WebHelper301MaxAgeSec       = (Get-CprTimingValue -Contract $contract -Key 'webhelper_301_max_age_sec' -Fallback $BaseWebHelper301MaxAgeSec -Maximum 3600)
        WebHelper301MaxRecords      = (Get-CprTimingValue -Contract $contract -Key 'webhelper_301_max_records' -Fallback $BaseWebHelper301MaxRecords -Maximum 5000)
        WebHelper301LogName         = (Get-CprTimingValue -Contract $contract -Key 'webhelper_301_log_name' -Fallback $CiscoWebHelperLogName)
        WebHelper301ProviderName    = (Get-CprTimingValue -Contract $contract -Key 'webhelper_301_provider_name' -Fallback $CiscoWebHelperProviderName)
    }
}

function Wait-BaseNetworkReady {
    <#
    Required D, Base side. Same contract as Main's Wait-CprNetworkReady, but
    Base is a SEPARATE standalone process that never dot-sources main\*.ps1,
    so the gate is implemented locally rather than shared. Polls cheap signals
    (default gateway reachable / preflight host resolvable), returns the moment
    one is observed, and is hard-capped - on expiry Base probes anyway and
    records signal='not_confirmed'. Never a fixed sleep.
    #>
    param(
        [string]$GatewayAddress = '',
        [string]$ProbeHost = '',
        [int]$MaxWaitMs = 8000,
        [int]$PollIntervalMs = 500,
        [int]$GatewayTimeoutMs = 750,
        [int]$DnsTimeoutMs = 1500,
        [switch]$Disabled
    )

    $result = @{ Ready = $false; Signal = 'not_confirmed'; WaitedMs = 0; Attempts = 0 }
    if ($Disabled) { $result.Signal = 'disabled'; return $result }

    $gateway = ''
    if (-not [string]::IsNullOrWhiteSpace($GatewayAddress)) {
        $candidate = $GatewayAddress.Trim()
        if (@('n/a', 'unknown', 'none', '0.0.0.0') -notcontains $candidate.ToLowerInvariant()) { $gateway = $candidate }
    }

    $probe = ''
    if (-not [string]::IsNullOrWhiteSpace($ProbeHost)) {
        $probe = $ProbeHost.Trim()
        try {
            $uri = $null
            if ([System.Uri]::TryCreate($probe, [System.UriKind]::Absolute, [ref]$uri) -and $uri) { $probe = $uri.Host }
        } catch { }
    }

    if (-not $gateway -and -not $probe) { $result.Signal = 'no_signals_available'; return $result }

    $startedAt = Get-Date
    while ($true) {
        $result.Attempts++

        if ($gateway) {
            $ping = $null
            try {
                $ping = New-Object System.Net.NetworkInformation.Ping
                $reply = $ping.Send($gateway, $GatewayTimeoutMs)
                if ($null -ne $reply -and $reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) {
                    $result.Ready = $true; $result.Signal = 'gateway_reachable'
                }
            } catch { } finally { if ($ping) { try { $ping.Dispose() } catch { } } }
            if ($result.Ready) { break }
        }

        if ($probe) {
            try {
                $task = [System.Net.Dns]::GetHostAddressesAsync($probe)
                if ($task.Wait($DnsTimeoutMs) -and $null -ne $task.Result -and $task.Result.Count -gt 0) {
                    $result.Ready = $true; $result.Signal = 'dns_resolved'
                }
            } catch { }
            if ($result.Ready) { break }
        }

        $elapsedMs = ((Get-Date) - $startedAt).TotalMilliseconds
        if ($elapsedMs + $PollIntervalMs -ge $MaxWaitMs) { break }
        Start-Sleep -Milliseconds $PollIntervalMs
    }

    $result.WaitedMs = [math]::Round(((Get-Date) - $startedAt).TotalMilliseconds)
    return $result
}

function Get-BaseTimerFromHandoff {
    <#
    Main is the source of truth for Base's timers. A sane positive value from
    the dispatch artifact wins; anything else falls back to the mirrored local
    literal. Never silently extends a wait beyond what Main asked for.
    #>
    param($StateData, [string]$Property, [int]$Fallback, [int]$Maximum = 3600)

    if ($null -eq $StateData) { return $Fallback }
    $value = 0
    if ([int]::TryParse([string]$StateData.$Property, [ref]$value) -and $value -gt 0 -and $value -le $Maximum) {
        return $value
    }
    return $Fallback
}

function Clear-BaseRemediationState {
    <#
    Lifecycle cleanup (Required F). On exit/timeout/network loss the artifact is
    removed promptly so the next run never reads the prior SSID.
    #>
    param([string]$Reason = 'base_exit')

    try {
        if (Test-Path $RemediationStateFile) {
            Remove-Item $RemediationStateFile -Force -ErrorAction SilentlyContinue
            Write-BaseCapLog "Remediation state artifact cleared (reason=$Reason)" "INFO"
        }
    } catch {
        Write-BaseCapLog "Could not clear remediation state artifact (reason=$Reason): $_" "DEBUG"
    }
}

function Send-EscalationFlare {
    Write-BaseCapLog "Base runner timeout - escalating to full runner (Event 777 captive_portal_browser)" "WARN"

    try {
        $eventArgs = @(
            "/T", "INFORMATION",
            "/ID", $EscalationEventId,
            "/L", "APPLICATION",
            "/SO", $EscalationEventSource,
            "/D", "FLARE:captive_portal_browser"
        )

        $proc = Start-Process -FilePath "eventcreate.exe" -ArgumentList $eventArgs -WindowStyle Hidden -Wait -PassThru -ErrorAction Stop
        if ($proc.ExitCode -eq 0) {
            Write-BaseCapLog "Escalation flare fired successfully (Event 777 captive_portal_browser)" "INFO"
            $null = Write-BaseCapTee -Tag 'flare_dispatched' -Data @{
                EvtTime = (Get-Date -Format 'o'); flare_tag = 'captive_portal_browser'
                event_id = [string]$EscalationEventId; context = 'USER'
                dispatch_method = 'eventcreate'; status = 'dispatched'; reason = 'base_escalation'
            }
        } else {
            Write-BaseCapLog "Escalation flare may have failed (ExitCode: $($proc.ExitCode))" "WARN"
            $null = Write-BaseCapTee -Tag 'flare_failed' -Data @{
                EvtTime = (Get-Date -Format 'o'); flare_tag = 'captive_portal_browser'
                event_id = [string]$EscalationEventId; context = 'USER'
                dispatch_method = 'eventcreate'; status = 'failed'; reason = "eventcreate_exit_code_$($proc.ExitCode)"
            }
        }
    } catch {
        Write-BaseCapLog "Failed to fire escalation flare: $_" "ERROR"
        $null = Write-BaseCapTee -Tag 'flare_failed' -Data @{
            EvtTime = (Get-Date -Format 'o'); flare_tag = 'captive_portal_browser'
            event_id = [string]$EscalationEventId; context = 'USER'
            dispatch_method = 'eventcreate'; status = 'failed'; reason = 'eventcreate_exception'
        }
    }
}

# ================================ MAIN ======================================

try {
    $baseProcessStartedAt = Get-Date
    Initialize-BaseCapPortalLogger
    Write-BaseCapLog ("phase_timing phase='startup_bootstrap' elapsed_ms={0} startup_elapsed_ms={0}" -f `
        [math]::Round(((Get-Date) - $baseProcessStartedAt).TotalMilliseconds)) "INFO"

    Write-BaseCapLog "=== CPR-Base (Captive Portal Base Observer) v1.0.0_RC1.25 Starting ===" "INFO"

    # ---- Required E: Main.Configuration.ps1 is the source of truth ----------
    # Read the dispatch artifact's timing_contract FIRST so every timer used
    # below (including the Required D readiness gate and the first preflight)
    # is Main's effective value. The literals at the top of this script are
    # fail-safe defaults used only when the artifact is absent/unreadable.
    $artifactReadStartedAt = Get-Date
    $dispatchArtifact = Read-BaseDispatchArtifact
    $baseTiming = Resolve-BaseTimingContract -StateData $dispatchArtifact
    Write-BaseCapLog ("phase_timing phase='timing_contract_artifact_read' elapsed_ms={0} startup_elapsed_ms={1}" -f `
        [math]::Round(((Get-Date) - $artifactReadStartedAt).TotalMilliseconds), `
        [math]::Round(((Get-Date) - $baseProcessStartedAt).TotalMilliseconds)) "INFO"
    $ObserveTimeoutSeconds         = $baseTiming.ObserveTimeoutSeconds
    $CheckIntervalSec              = $baseTiming.CheckIntervalSec
    $BasePreflightTimeoutMs        = $baseTiming.PreflightTimeoutMs
    $BasePreflightMaxProbes        = $baseTiming.PreflightMaxProbes
    $CiscoWebHelperLookbackSeconds = $baseTiming.WebHelperLookbackSeconds
    $BaseWebHelper301MaxRecords    = $baseTiming.WebHelper301MaxRecords
    $CiscoWebHelperLogName         = $baseTiming.WebHelper301LogName
    $CiscoWebHelperProviderName    = $baseTiming.WebHelper301ProviderName
    $MaxHandoffAgeSeconds          = $baseTiming.MaxHandoffAgeSeconds
    $ValidationSite                = $baseTiming.ValidationSite
    $BaseSiteTimeoutSec            = $baseTiming.SiteTimeoutSec
    $BasePreflightUrl              = $baseTiming.PreflightUrl
    Write-BaseCapLog ("cap_portal_timing_contract source='{0}' base_observe_timeout_sec={1} base_check_interval_sec={2} base_preflight_timeout_ms={3} base_preflight_max_probes={4} base_webhelper_lookback_sec={5} handoff_max_age_sec={6} validation_site='{7}' preflight_url='{8}' network_ready_max_wait_ms={9} network_ready_poll_interval_ms={10} webhelper_301_suppress_preflight={11} webhelper_301_max_age_sec={12}" -f `
        $baseTiming.Source, $ObserveTimeoutSeconds, $CheckIntervalSec, $BasePreflightTimeoutMs, `
        $BasePreflightMaxProbes, $CiscoWebHelperLookbackSeconds, $MaxHandoffAgeSeconds, `
        $ValidationSite, $BasePreflightUrl, $baseTiming.NetworkReadyMaxWaitMs, $baseTiming.NetworkReadyPollIntervalMs, `
        $baseTiming.SuppressPreflightForWebHelper301, $baseTiming.WebHelper301MaxAgeSec) "INFO"

    Write-BaseCapLog "ObserveTimeoutSeconds: $ObserveTimeoutSeconds" "INFO"
    Write-BaseCapLog "CheckIntervalSec: $CheckIntervalSec" "INFO"
    Write-BaseCapLog "ValidationSite: $ValidationSite" "INFO"
    Write-BaseCapLog "FlagFile: $FlagFile" "INFO"

    # Read and log VPN profile from registry
    $vpnProfile = (Get-ItemProperty -Path "HKLM:\SYSTEM\UHG\DSM" -ErrorAction SilentlyContinue).VPN
    if ($vpnProfile) {
        Write-BaseCapLog "VPN profile: $vpnProfile" "INFO"
    } else {
        Write-BaseCapLog "VPN profile: NOT_SET" "WARN"
    }

    $portalIP = ""
    $portalFQDN = ""
    $portalProtocol = ""
    $portalPort = 0
    $portalSsid = ""
    $portalTypeValue = ""
    $portalUrl = ""
    # Main's handoff context (dispatch_context) stays separate from Base's own
    # preflight and from optional WebHelper EventID 301 evidence.
    $dispatchContext = $null
    $mainHandoffRedirectUrl = ""

    # Local network context - gathered by THIS process (RC1.25). The base runner
    # is launched by Task Scheduler and shares no scope with WW_main.ps1.
    $baseStartedAt = Get-Date
    $networkSnapshotStartedAt = Get-Date
    $netCtx = Get-BaseCapNetworkContext
    Write-BaseCapLog ("phase_timing phase='network_context_snapshot' elapsed_ms={0} startup_elapsed_ms={1}" -f `
        [math]::Round(((Get-Date) - $networkSnapshotStartedAt).TotalMilliseconds), `
        [math]::Round(((Get-Date) - $baseProcessStartedAt).TotalMilliseconds)) "INFO"
    Write-BaseCapLog "Local network context: ssid='$($netCtx.ssid)' ip='$($netCtx.ip)' gw='$($netCtx.gw)' dns='$($netCtx.dns)'" "INFO"

    # ---- Required B: strict network re-check BEFORE any observation work ----
    # The network can disappear between Main's dispatch and this launch. When it
    # has, exit in SECONDS - never burn the full observation window and never
    # escalate to the full runner.
    $baseConnectionType = if ($netCtx.adapter_class -eq 'wifi') { 'WiFi' } elseif ($netCtx.adapter_class -eq 'ethernet') { 'Ethernet' } else { '' }
    $networkGate = Test-BaseLocalNetworkReady -NetworkContext $netCtx -ConnectionType $baseConnectionType
    if (-not $networkGate.Ready) {
        Write-BaseCapLog "network_unavailable_before_observation reason='$($networkGate.Reason)' ssid='$($netCtx.ssid)' ip='$($netCtx.ip)' gw='$($netCtx.gw)' - no usable local network at Base startup" "WARN"
        Write-BaseCapLog "Exiting immediately: no observation window, no Event 777, no full-runner launch" "WARN"
        Write-BaseCapRunnerLifecycleTelemetry -Action 'flare_runner_started' -Status 'started' -Reason 'captive_portal_browser_base_event_778' -NetworkContext $netCtx -VpnState ''
        Write-CompletionFlag -Status "NO_NETWORK" -Details "network_unavailable_before_observation ($($networkGate.Reason)) - Base exited without observing or escalating" -CaptiveBrowserPID 0
        Write-BaseCapRunnerLifecycleTelemetry -Action 'flare_runner_completed' -Status 'no_network' -Reason 'network_unavailable_before_observation' -NetworkContext $netCtx -VpnState '' -DurationSec ([string][math]::Round(((Get-Date) - $baseStartedAt).TotalSeconds))
        Clear-BaseRemediationState -Reason 'network_unavailable_before_observation'
        Write-BaseCapLog "=== CPR-Base Complete (observe-only, no network) ===" "INFO"
        exit 0
    }
    $baseNetworkReadyAt = Get-Date
    Write-BaseCapLog "Local network gate passed (reason='$($networkGate.Reason)' connection_type='$(if ($baseConnectionType) { $baseConnectionType } else { 'Wired' })')" "INFO"

    # Validate Main's artifact before it is allowed to suppress any probe.
    # A stale/prior-SSID 301 must never affect this run.
    $suppressBasePreflight = $false
    $dispatchWebHelper = $null
    if ($null -ne $dispatchArtifact) {
        $earlyHandoffCheck = Test-BaseHandoffArtifact -StateData $dispatchArtifact `
            -NetworkContext $netCtx -MaxAgeSeconds $MaxHandoffAgeSeconds
        if ($earlyHandoffCheck.Accepted -and
            @($dispatchArtifact.PSObject.Properties.Name) -contains 'webhelper_navigation') {
            $candidate = $dispatchArtifact.webhelper_navigation
            $candidateAgeSec = [double]::PositiveInfinity
            try { $candidateAgeSec = ((Get-Date) - ([datetime]$candidate.EventTime)).TotalSeconds } catch { }
            if ($candidate -and $candidate.UsableNavigation -and $candidate.NavigatedUrl -and
                $candidate.Source -eq 'cisco_webhelper_301' -and
                $candidate.Classification -ne 'ISE_EMPLOYEE' -and
                $candidateAgeSec -ge -5 -and
                $candidateAgeSec -le $baseTiming.WebHelper301MaxAgeSec -and
                $baseTiming.SuppressPreflightForWebHelper301) {
                $dispatchWebHelper = $candidate
                $suppressBasePreflight = $true
            } elseif ($candidate -and $candidate.NavigatedUrl) {
                Write-BaseCapLog "Main EventID 301 evidence not eligible to suppress Base preflight (age_sec='$([math]::Round($candidateAgeSec, 1))' classification='$($candidate.Classification)')" "INFO"
            }
        }
    }

    # ---- Required C/D: selected evidence before gateway preflight -----------
    # With no accepted active 301 evidence, the bounded readiness gate and
    # authoritative gateway preflight remain unchanged. With accepted evidence,
    # avoid a request AlwaysOn/WebView2 is known to block; connectivity validation
    # below still owns the remediation-success decision.
    $basePreflightObservation = $null
    if ($suppressBasePreflight) {
        $basePreflightObservation = [PSCustomObject]@{
            observation_time = (Get-Date -Format 'o'); probe_url = $BasePreflightUrl
            status = 'suppressed'; classification = 'REDIRECT'; http_status = ''
            redirect_url = [string]$dispatchWebHelper.NavigatedUrl
            redirect_type = [string]$dispatchWebHelper.Classification
            protocol = [string]$dispatchWebHelper.Protocol; fqdn = [string]$dispatchWebHelper.Fqdn
            port = [string]$dispatchWebHelper.Port; duration_ms = 0; attempt = 0
            reason = 'active_cisco_webhelper_301_navigation'; error_message = ''
        }
        Write-BaseCapLog "detection_source=cisco_webhelper_301 - accepted fresh Main navigation; gateway_preflight suppressed while WebView2 owns the path" "WARN"
        Write-BaseCapLog "preflight_timing network_ready_to_preflight_ms=-1 network_ready_to_preflight_sec=-1 startup_to_preflight_ms=-1 preflight_duration_ms=0 status='suppressed' gateway_preflight_ran=false" "INFO"
    } else {
    # Required D: bounded network-settle gate between the fast network gate and
    # the first authoritative probe. Fires the probe the moment a cheap signal
    # is observed; capped, then probes anyway recording 'not_confirmed'.
        $baseReadiness = Wait-BaseNetworkReady -GatewayAddress $netCtx.gw -ProbeHost $BasePreflightUrl `
            -MaxWaitMs $baseTiming.NetworkReadyMaxWaitMs -PollIntervalMs $baseTiming.NetworkReadyPollIntervalMs `
            -GatewayTimeoutMs $baseTiming.NetworkReadyGatewayTimeoutMs -DnsTimeoutMs $baseTiming.NetworkReadyDnsTimeoutMs `
            -Disabled:(-not $BaseNetworkReadyEnabled)
        Write-BaseCapLog ("network_ready_gate network_ready_wait_ms={0} signal='{1}' attempts={2} max_wait_ms={3}" -f `
            $baseReadiness.WaitedMs, $baseReadiness.Signal, $baseReadiness.Attempts, $baseTiming.NetworkReadyMaxWaitMs) `
            $(if ($baseReadiness.Ready) { 'INFO' } else { 'WARN' })

        $basePreflightStartedAt = Get-Date
        Write-BaseCapLog "detection_source=gateway_preflight - no accepted usable Main EventID 301 navigation" "INFO"
        $basePreflightObservation = Test-BaseCapPreflight
        $basePreflightFinishedAt = Get-Date
        $networkReadyToPreflightMs = [math]::Round(($basePreflightStartedAt - $baseNetworkReadyAt).TotalMilliseconds)
        Write-BaseCapLog ("preflight_timing network_ready_to_preflight_ms={0} network_ready_to_preflight_sec={1} startup_to_preflight_ms={2} preflight_duration_ms={3} status='{4}'" -f `
            $networkReadyToPreflightMs, [math]::Round($networkReadyToPreflightMs / 1000, 2), `
            [math]::Round(($basePreflightStartedAt - $baseProcessStartedAt).TotalMilliseconds), `
            [math]::Round(($basePreflightFinishedAt - $basePreflightStartedAt).TotalMilliseconds), `
            $basePreflightObservation.status) "INFO"
    }
    # Single VPN state read for this cycle; shared by every log/telemetry line.
    $baseVpnState = Get-BaseCapVpnState
    Write-BaseCapRunnerLifecycleTelemetry -Action 'flare_runner_started' -Status 'started' -Reason 'captive_portal_browser_base_event_778' -NetworkContext $netCtx -VpnState $baseVpnState
    if (-not $suppressBasePreflight) {
        Write-BaseCapLog "cap_portal_preflight_observation status='$($basePreflightObservation.status)' probe_url='$($basePreflightObservation.probe_url)' http_status='$($basePreflightObservation.http_status)' redirect_url='$($basePreflightObservation.redirect_url)' redirect_type='$($basePreflightObservation.redirect_type)' reason='$($basePreflightObservation.reason)' duration_ms='$($basePreflightObservation.duration_ms)'" $(if ($basePreflightObservation.status -eq 'redirect') { 'INFO' } else { 'WARN' })
        Write-BaseCapPreflightFinding -Observation $basePreflightObservation
        Write-BaseCapPreflightTelemetry -Observation $basePreflightObservation -NetworkContext $netCtx -VpnState $baseVpnState
    }

    # Read and log remediation state file context
    if (Test-Path $RemediationStateFile) {
        try {
            # Already read once above for the timing contract (configuration
            # only); acceptance is still decided here and a rejected handoff
            # supplies no portal context.
            $stateData = $dispatchArtifact
            if ($null -eq $stateData) {
                $stateData = Get-Content -Path $RemediationStateFile -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            }
            Write-BaseCapLog "Remediation context: portal_type=$($stateData.portal_type) gateway_ip=$($stateData.gateway_ip) ssid=$($stateData.ssid)" "INFO"

            # ---- Required F: reject a handoff that no longer describes reality
            $handoffCheck = Test-BaseHandoffArtifact -StateData $stateData -NetworkContext $netCtx -MaxAgeSeconds $MaxHandoffAgeSeconds
            if (-not $handoffCheck.Accepted) {
                Write-BaseCapLog "$($handoffCheck.Reason) age_sec='$($handoffCheck.AgeSeconds)' handoff_context: ssid='$($stateData.ssid)' ip='$($stateData.ip)' gw='$($stateData.gw)' gateway_ip='$($stateData.gateway_ip)' | live_context: ssid='$($netCtx.ssid)' ip='$($netCtx.ip)' gw='$($netCtx.gw)'" "WARN"
                Write-BaseCapLog "Handoff artifact ignored - Base uses its own live context and its own empirical preflight only" "WARN"
                $stateData = $null
            }
        } catch {
            Write-BaseCapLog "Could not parse remediation state file: $_" "DEBUG"
            $stateData = $null
        }
    } else {
        Write-BaseCapLog "No remediation state file present - url/port/portal_type will be empty in telemetry" "WARN"
    }

    # ---- Required A: effective Base -> Full escalation policy ---------------
    $escalationPolicy = Resolve-BaseEscalationPolicy -StateData $stateData
    $BaseAllowFullEscalation = [bool]$escalationPolicy.Allowed
    Write-BaseCapLog "cap_portal_base_escalation_policy allow_full_escalation=$BaseAllowFullEscalation source=$($escalationPolicy.Source)" "INFO"

    # ---- Required E: Main is the source of truth for Base's timers ---------
    $ObserveTimeoutSeconds = Get-BaseTimerFromHandoff -StateData $stateData -Property 'base_observe_timeout_sec' -Fallback $ObserveTimeoutSeconds
    $CheckIntervalSec      = Get-BaseTimerFromHandoff -StateData $stateData -Property 'base_check_interval_sec' -Fallback $CheckIntervalSec -Maximum 300
    Write-BaseCapLog "cap_portal_base_timers observe_timeout_sec=$ObserveTimeoutSeconds check_interval_sec=$CheckIntervalSec" "INFO"

    if ($null -ne $stateData) {
        try {
            if ($null -ne $stateData.dispatch_context) {
                # B/E: Main's authoritative preflight at the moment it fired
                # 777/778. Kept SEPARATE from this process's own later probe and
                # from optional EventID 301 corroboration.
                $dispatchContext = $stateData.dispatch_context
                $mainHandoffRedirectUrl = [string]$dispatchContext.redirect_url
                Write-BaseCapLog "Main dispatch context: run_id='$($dispatchContext.run_id)' flare_tag='$($dispatchContext.flare_tag)' event_id='$($dispatchContext.event_id)' runner_mode='$($dispatchContext.runner_mode)' probe_url='$($dispatchContext.probe_url)' preflight_status='$($dispatchContext.preflight_status)' classification='$($dispatchContext.classification)' redirect_url='$($dispatchContext.redirect_url)' redirect_type='$($dispatchContext.redirect_type)' protocol='$($dispatchContext.protocol)' fqdn='$($dispatchContext.fqdn)' port='$($dispatchContext.port)' ssid='$($dispatchContext.ssid)' ip='$($dispatchContext.ip)' gw='$($dispatchContext.gw)' dns='$($dispatchContext.dns)' vpn_state='$($dispatchContext.vpn_state)' status='$($dispatchContext.status)' reason='$($dispatchContext.reason)'" "INFO"
            } else {
                Write-BaseCapLog "No Main dispatch context in remediation state - handoff preflight context unavailable (reason='no_dispatch_context')" "WARN"
            }
            if ($stateData.portal_type) { $portalTypeValue = [string]$stateData.portal_type }
            if ($stateData.ssid) { $portalSsid = [string]$stateData.ssid }
            if ($stateData.url) { $portalUrl = [string]$stateData.url }

            if ($stateData.portal_type -eq "walled_garden") {
                if ($stateData.gateway_ip) { $portalIP = [string]$stateData.gateway_ip }
                $portalFQDN = if ($stateData.fqdn) { [string]$stateData.fqdn } else { $portalIP }
                $portalProtocol = if ($stateData.protocol) { [string]$stateData.protocol } else { "http" }
                $portalPort = if ($stateData.port) { [int]$stateData.port } else { 80 }
            } else {
                if ($stateData.ip) { $portalIP = [string]$stateData.ip }
                if ($stateData.fqdn) { $portalFQDN = [string]$stateData.fqdn }
                if ($stateData.protocol) { $portalProtocol = [string]$stateData.protocol }
                if ($stateData.port) { $portalPort = [int]$stateData.port }
            }

            # RC1.25: WW_main.ps1 now also hands over the network context it had
            # at detection time. Prefer this process's own live reading; fall back
            # to the handed-over value when the local probe came up empty.
            if ([string]::IsNullOrWhiteSpace($netCtx.ip)  -and $stateData.ip)  { $netCtx.ip  = [string]$stateData.ip }
            if ([string]::IsNullOrWhiteSpace($netCtx.gw)  -and $stateData.gw)  { $netCtx.gw  = [string]$stateData.gw }
            if ([string]::IsNullOrWhiteSpace($netCtx.dns) -and $stateData.dns) { $netCtx.dns = [string]$stateData.dns }
        } catch {
            Write-BaseCapLog "Could not apply remediation state context: $_" "DEBUG"
        }
    }

    # Normalized telemetry prefers the live SSID this process measured; the state
    # file value is the fallback when the radio reports nothing.
    $telemetrySsid = if (-not [string]::IsNullOrWhiteSpace($netCtx.ssid)) { $netCtx.ssid } else { $portalSsid }
    if ([string]::IsNullOrWhiteSpace($telemetrySsid)) {
        Write-BaseCapLog "SSID unavailable from both netsh and remediation state - ssid emitted empty" "WARN"
    }

    Write-BaseCapLog "Observer mode active - NOT killing Cisco browsers, NOT opening Edge" "INFO"
    Write-BaseCapLog "Cisco Secure Client is expected to handle captive portal natively" "INFO"
    if ($BaseAllowFullEscalation) {
        Write-BaseCapLog "Will escalate to full runner (Event 777) if not resolved within ${ObserveTimeoutSeconds}s" "INFO"
    } else {
        Write-BaseCapLog "Base -> Full escalation is DISABLED - observe-only run: no Event 777 and no full runner launch on timeout" "INFO"
    }

    $observed = $false
    $startTime = Get-Date
    $endTime = $startTime.AddSeconds($ObserveTimeoutSeconds)
    # Pre-start lookback: Cisco's WebView2 frequently pops and logs EventID 301
    # before Event 778 ever launches this process.
    $webHelperSince = $startTime.AddSeconds(-$CiscoWebHelperLookbackSeconds)
    Write-BaseCapLog "Cisco WebHelper EventID 301 lookback window starts at $($webHelperSince.ToString('o')) (${CiscoWebHelperLookbackSeconds}s before Base start)" "INFO"
    $iteration = 0
    $preflightProbes = $(if ($suppressBasePreflight) { $BasePreflightMaxProbes } else { 1 })
    $baseRedirectFinding = ($basePreflightObservation.status -in @('redirect','suppressed'))
    $seenWebHelperPids = @{}
    # Required D: records already examined in an earlier cycle are never
    # re-parsed or re-logged.
    $seenWebHelperRecordIds = @{}
    $webHelperNavigationSeen = $false
    $webHelperNavigationUrl = ""; $webHelperFinalUrl = ""; $webHelperFinalUrlPort = 0
    $webHelperProcessId = ""; $webHelperThreadId = ""; $webHelperApName = ""
    $webHelperApTags = ""; $webHelperApMac = ""; $webHelperSip = ""; $webHelperOrg = ""
    $webHelperUi = ""; $webHelperPsid = ""; $webHelperLoginUrl = ""; $webHelperMa = ""
    $webHelperOs = ""; $webHelperApiDomain = ""; $webHelperDedupeKey = ""; $webHelperEventTime = $null
    $webHelperOsName = ""; $webHelperOsVersion = ""; $webHelperBrowserName = ""
    $webHelperBrowserVersion = ""; $webHelperDeviceType = ""; $webHelperTraceId = ""
    $webHelperEventRecordId = ""
    # Every distinct navigation stage is kept; only repeated reads of the same
    # event record are suppressed (one PID emits many stages).
    $webHelperNavigationStages = @()
    $webHelperError = ""

    while ((Get-Date) -lt $endTime) {
        $cycleStartedAt = Get-Date
        $iteration++
        $elapsed = [math]::Round(((Get-Date) - $startTime).TotalSeconds)
        $remaining = [math]::Round(($endTime - (Get-Date)).TotalSeconds)
        # Required D: exactly ONE vpncli.exe invocation per observe cycle; the
        # value is then passed to every log and telemetry call below.
        Reset-BaseCapVpnStateCache
        $vpnState = Get-BaseCapVpnState

        $webHelperEvent = Get-CiscoWebHelperNavigationEvent -Since $webHelperSince `
            -MaxEvents $BaseWebHelper301MaxRecords -SeenProcessIds $seenWebHelperPids `
            -SeenRecordIds $seenWebHelperRecordIds
        if ($webHelperEvent.NonNavigationCount -gt 0) {
            Write-BaseCapLog "cisco_webhelper_scan cycle=$iteration examined=$($webHelperEvent.ExaminedCount) without_navigation_url=$($webHelperEvent.NonNavigationCount) already_seen=$($webHelperEvent.SkippedSeenCount)" "DEBUG"
        }
        if ($webHelperEvent.Found) {
            if (-not [string]::IsNullOrEmpty($webHelperEvent.DedupeKey)) {
                $seenWebHelperPids[$webHelperEvent.DedupeKey] = $true
            }
            $webHelperNavigationSeen = $true
            $webHelperNavigationUrl = $webHelperEvent.NavigatedUrl
            $webHelperFinalUrl = $webHelperEvent.FinalUrl
            $webHelperFinalUrlPort = $webHelperEvent.FinalUrlPort
            $webHelperProcessId = $webHelperEvent.ProcessId
            $webHelperThreadId = $webHelperEvent.ThreadId
            $webHelperApName = $webHelperEvent.ApName; $webHelperApTags = $webHelperEvent.ApTags
            $webHelperApMac = $webHelperEvent.ApMac; $webHelperSip = $webHelperEvent.Sip
            $webHelperOrg = $webHelperEvent.Org; $webHelperUi = $webHelperEvent.Ui
            $webHelperPsid = $webHelperEvent.Psid; $webHelperLoginUrl = $webHelperEvent.LoginUrl
            $webHelperMa = $webHelperEvent.Ma; $webHelperOs = $webHelperEvent.Os
            $webHelperApiDomain = $webHelperEvent.ApiDomain
            $webHelperOsName = $webHelperEvent.OsName; $webHelperOsVersion = $webHelperEvent.OsVersion
            $webHelperBrowserName = $webHelperEvent.BrowserName; $webHelperBrowserVersion = $webHelperEvent.BrowserVersion
            $webHelperDeviceType = $webHelperEvent.DeviceType; $webHelperTraceId = $webHelperEvent.TraceId
            $webHelperEventRecordId = $webHelperEvent.EventRecordId
            $webHelperDedupeKey = $webHelperEvent.DedupeKey; $webHelperEventTime = $webHelperEvent.EventTime
            # Keep earlier distinct stages; the latest valid navigation is the
            # one handed back as the best corroborating evidence.
            $webHelperNavigationStages += [PSCustomObject]@{
                navigated_url = $webHelperEvent.NavigatedUrl; final_url = $webHelperEvent.FinalUrl
                event_time = if ($webHelperEvent.EventTime) { $webHelperEvent.EventTime.ToString('o') } else { '' }
                process_id = $webHelperEvent.ProcessId; event_record_id = $webHelperEvent.EventRecordId
            }
            Write-BaseCapLog "cisco_webhelper_navigation navigated_url='$webHelperNavigationUrl' final_url='$webHelperFinalUrl' ap_name='$webHelperApName' ap_mac='$webHelperApMac' pid='$webHelperProcessId' event_time='$webHelperEventTime'" "INFO"
            Write-BaseCapWebHelperTelemetry -Navigation $webHelperEvent -NetworkContext $netCtx -VpnState $vpnState
        } elseif ($webHelperEvent.Error) {
            $webHelperError = $webHelperEvent.Error
        }

        # Poll the empirical probe rather than trusting a single attempt: a
        # portal that only starts redirecting a few seconds later is still
        # captured. Bounded, fail-soft, and still observe-only.
        if (-not $suppressBasePreflight -and -not $baseRedirectFinding -and $preflightProbes -lt $BasePreflightMaxProbes) {
            $preflightProbes++
            try {
                $remainingOperationMs = [math]::Floor(($endTime - (Get-Date)).TotalMilliseconds)
                if ($remainingOperationMs -le 0) { break }
                $retryObservation = Test-BaseCapPreflight -TimeoutMs ([math]::Max(1, [math]::Min($BasePreflightTimeoutMs, $remainingOperationMs)))
                $retryObservation.attempt = $preflightProbes
                if ($retryObservation.status -eq 'redirect') {
                    $baseRedirectFinding = $true
                    $basePreflightObservation = $retryObservation
                    Write-BaseCapLog "Base empirical probe attempt $preflightProbes found a redirect Main never saw" "WARN"
                    Write-BaseCapPreflightFinding -Observation $retryObservation
                    Write-BaseCapPreflightTelemetry -Observation $retryObservation -NetworkContext $netCtx -VpnState $vpnState
                } else {
                    Write-BaseCapLog "Base empirical probe attempt $preflightProbes - status='$($retryObservation.status)' reason='$($retryObservation.reason)'" "DEBUG"
                }
            } catch {
                Write-BaseCapLog "Base empirical probe attempt $preflightProbes failed: $_" "DEBUG"
            }
        }

        $remainingSiteMs = [math]::Floor(($endTime - (Get-Date)).TotalMilliseconds)
        if ($remainingSiteMs -lt 1000) { break }
        $siteTimeoutSec = [math]::Max(1, [math]::Min($BaseSiteTimeoutSec, [math]::Floor($remainingSiteMs / 1000)))
        if (Test-SiteReachability -TimeoutSec $siteTimeoutSec) {
            Write-BaseCapLog "Connectivity confirmed after ${elapsed}s - Cisco client resolved captive portal natively" "INFO"
            # Normalized telemetry URL/port are derived BEFORE the legacy
            # "unknown" placeholders below are applied, so a normalized row
            # carries an explicit empty value instead of the string "unknown".
            $telemetryUrl  = Get-BaseCapTelemetryUrl -Url $portalUrl -Protocol $portalProtocol -Fqdn $portalFQDN -WebHelperNavigatedUrl $webHelperNavigationUrl -PreflightRedirectUrl $basePreflightObservation.redirect_url -MainHandoffRedirectUrl $mainHandoffRedirectUrl
            $telemetryPort = if ($portalPort -gt 0) { "$portalPort" } else { "" }
            if ([string]::IsNullOrWhiteSpace($portalIP)) { $portalIP = "unknown" }
            if ([string]::IsNullOrWhiteSpace($portalFQDN)) { $portalFQDN = "unknown" }
            if ([string]::IsNullOrWhiteSpace($portalProtocol)) { $portalProtocol = "unknown" }
            if ($portalPort -le 0) { $portalPort = 0 }
            # LEGACY event (action="network_state_change") - kept for existing
            # Splunk views; NOT a normalized cap_portal_* outcome row.
            Write-CaptivePortalEventToHayStack -IP $portalIP -FQDN $portalFQDN -Protocol $portalProtocol -Port $portalPort
            if (-not $webHelperNavigationSeen) {
                $missingNavigation = [PSCustomObject]@{ EventTime = $null; NavigatedUrl = ''; FinalUrl = ''; FinalUrlPort = 0; ProcessId = ''; ThreadId = ''; ApName = ''; ApTags = ''; ApMac = ''; Sip = ''; Org = ''; Ui = ''; Psid = ''; LoginUrl = ''; Ma = ''; Os = ''; ApiDomain = '' }
                $baseRedirectType = Get-BaseCapEffectiveRedirectType -PreflightObservation $basePreflightObservation -DispatchContext $dispatchContext
                $missingOutcome = Get-BaseCapMissingNavigationOutcome -RedirectType $baseRedirectType -WebHelperError $webHelperError -DefaultReason 'native_resolution_without_event_301_navigation'
                Write-BaseCapLog "cap_portal_webhelper_navigation status='$($missingOutcome.Outcome)' reason='$($missingOutcome.Reason)' (EventID 301 is optional corroboration only)" $missingOutcome.Level
                Write-BaseCapWebHelperTelemetry -Navigation $missingNavigation -NetworkContext $netCtx -VpnState $vpnState -Outcome $missingOutcome.Outcome -Reason $missingOutcome.Reason
            }
            $webHelperHandback = [PSCustomObject]@{
                observed = $webHelperNavigationSeen; navigated_url = $webHelperNavigationUrl; final_url = $webHelperFinalUrl; final_url_port = $webHelperFinalUrlPort
                process_id = $webHelperProcessId; thread_id = $webHelperThreadId; ap_name = $webHelperApName; ap_tags = $webHelperApTags; ap_mac = $webHelperApMac
                sip = $webHelperSip; org = $webHelperOrg; ui = $webHelperUi; psid = $webHelperPsid; login_url = $webHelperLoginUrl; ma = $webHelperMa
                os = $webHelperOs; api_domain = $webHelperApiDomain; os_name = $webHelperOsName; os_version = $webHelperOsVersion
                browser_name = $webHelperBrowserName; browser_version = $webHelperBrowserVersion; device_type = $webHelperDeviceType
                trace_id = $webHelperTraceId; event_record_id = $webHelperEventRecordId
                event_time = if ($webHelperEventTime) { $webHelperEventTime.ToString('o') } else { '' }
                navigation_stages = $webHelperNavigationStages
                reason = $webHelperError
            }
            Write-CompletionFlag -Status "SUCCESS_NATIVE" -Details "Captive portal resolved by Cisco Secure Client in ${elapsed}s" -CaptiveBrowserPID 0 -PreflightObservation $basePreflightObservation -WebHelperNavigation $webHelperHandback
            Write-BaseCapOutcomeTelemetry -Action 'cap_portal_remediation_passed' `
                -Url $telemetryUrl `
                -Port $telemetryPort `
                -PortalType $portalTypeValue `
                -Status 'verified' `
                -Reason 'native_resolution' `
                -Ssid $telemetrySsid `
                -VpnState $vpnState `
                -Ip $netCtx.ip `
                -Gw $netCtx.gw `
                -Dns $netCtx.dns
            $observed = $true
            Write-BaseCapRunnerLifecycleTelemetry -Action 'flare_runner_completed' -Status 'completed' -Reason 'native_resolution' -NetworkContext $netCtx -VpnState $vpnState -DurationSec ([string]$elapsed)
            break
        }

        # Required D: deadline-aware sleep. The configured observation window
        # must not become 125s/131s because a tail sleep overshoots the
        # deadline. Never sleep past $endTime.
        $cycleFinishedAt = Get-Date
        $cycleWorkMs = [math]::Round(($cycleFinishedAt - $cycleStartedAt).TotalMilliseconds)
        $remainingMs = [math]::Max(0, [math]::Floor(($endTime - $cycleFinishedAt).TotalMilliseconds))
        $targetSleepMs = [math]::Max(0, ($CheckIntervalSec * 1000) - $cycleWorkMs)
        $sleepMs = [math]::Min($targetSleepMs, $remainingMs)
        Write-BaseCapLog ("base_observe_cycle cycle={0} work_ms={1} sleep_ms={2} remaining_ms={3} vpn_state='{4}'" -f `
            $iteration, $cycleWorkMs, $sleepMs, $remainingMs, $vpnState) "INFO"
        if ($sleepMs -gt 0) { Start-Sleep -Milliseconds $sleepMs }
    }

    if (-not $observed) {
        $elapsed = [math]::Round(((Get-Date) - $startTime).TotalSeconds)
        Write-BaseCapLog "Observation window expired after ${elapsed}s - native resolution did not complete" "WARN"
        Reset-BaseCapVpnStateCache
        $vpnState = Get-BaseCapVpnState
        if ($BaseAllowFullEscalation) {
            Write-BaseCapLog "Escalating to full runner via captive_portal_browser flare (Event 777)" "WARN"
        } else {
            Write-BaseCapLog "Base -> Full escalation disabled (allow_full_escalation=False) - NOT firing Event 777 and NOT launching the full runner; completing observe-only" "WARN"
        }
        if (-not $webHelperNavigationSeen) {
            $missingNavigation = [PSCustomObject]@{ EventTime = $null; NavigatedUrl = ''; FinalUrl = ''; FinalUrlPort = 0; ProcessId = ''; ThreadId = ''; ApName = ''; ApTags = ''; ApMac = ''; Sip = ''; Org = ''; Ui = ''; Psid = ''; LoginUrl = ''; Ma = ''; Os = ''; ApiDomain = '' }
            $baseRedirectType = Get-BaseCapEffectiveRedirectType -PreflightObservation $basePreflightObservation -DispatchContext $dispatchContext
            $missingOutcome = Get-BaseCapMissingNavigationOutcome -RedirectType $baseRedirectType -WebHelperError $webHelperError -DefaultReason 'observation_window_expired_without_event_301_navigation'
            Write-BaseCapLog "cap_portal_webhelper_navigation status='$($missingOutcome.Outcome)' reason='$($missingOutcome.Reason)' (EventID 301 is optional corroboration only)" $missingOutcome.Level
            Write-BaseCapWebHelperTelemetry -Navigation $missingNavigation -NetworkContext $netCtx -VpnState $vpnState -Outcome $missingOutcome.Outcome -Reason $missingOutcome.Reason
        }
        $webHelperHandback = [PSCustomObject]@{
            observed = $webHelperNavigationSeen; navigated_url = $webHelperNavigationUrl; final_url = $webHelperFinalUrl; final_url_port = $webHelperFinalUrlPort
            process_id = $webHelperProcessId; thread_id = $webHelperThreadId; ap_name = $webHelperApName; ap_tags = $webHelperApTags; ap_mac = $webHelperApMac
            sip = $webHelperSip; org = $webHelperOrg; ui = $webHelperUi; psid = $webHelperPsid; login_url = $webHelperLoginUrl; ma = $webHelperMa
            os = $webHelperOs; api_domain = $webHelperApiDomain; os_name = $webHelperOsName; os_version = $webHelperOsVersion
            browser_name = $webHelperBrowserName; browser_version = $webHelperBrowserVersion; device_type = $webHelperDeviceType
            trace_id = $webHelperTraceId; event_record_id = $webHelperEventRecordId
            event_time = if ($webHelperEventTime) { $webHelperEventTime.ToString('o') } else { '' }
            navigation_stages = $webHelperNavigationStages
            reason = if ($webHelperNavigationSeen) { '' } elseif ($webHelperError) { $webHelperError } else { 'observation_window_expired_without_event_301_navigation' }
        }
        # Truthful outcome regardless of escalation policy. A WebView2/EventID
        # 301 navigation is EVIDENCE ONLY - it never makes this a remediation
        # success. Only the authoritative connectivity verification can.
        $timeoutStatus = if ($BaseAllowFullEscalation) { 'TIMEOUT_NATIVE' } else { 'TIMEOUT_OBSERVE_ONLY' }
        $timeoutReason = if ($BaseAllowFullEscalation) { 'native_timeout_escalated' } else { 'native_timeout_observe_only_no_escalation' }
        $timeoutDetails = if ($BaseAllowFullEscalation) {
            "Cisco client did not resolve captive portal within ${ObserveTimeoutSeconds}s - escalating to WW_cap_portal_runner.ps1"
        } else {
            "Cisco client did not resolve captive portal within ${ObserveTimeoutSeconds}s - observe-only: Base -> Full escalation disabled, no Event 777 fired"
        }
        Write-CompletionFlag -Status $timeoutStatus -Details $timeoutDetails -CaptiveBrowserPID 0 -PreflightObservation $basePreflightObservation -WebHelperNavigation $webHelperHandback
        Write-BaseCapOutcomeTelemetry -Action 'cap_portal_remediation_failed' `
            -Url (Get-BaseCapTelemetryUrl -Url $portalUrl -Protocol $portalProtocol -Fqdn $portalFQDN -WebHelperNavigatedUrl $webHelperNavigationUrl -PreflightRedirectUrl $basePreflightObservation.redirect_url -MainHandoffRedirectUrl $mainHandoffRedirectUrl) `
            -Port $(if ($portalPort -gt 0) { "$portalPort" } else { "" }) `
            -PortalType $portalTypeValue `
            -Status 'timeout' `
            -Reason $timeoutReason `
            -Ssid $telemetrySsid `
            -VpnState $vpnState `
            -Ip $netCtx.ip `
            -Gw $netCtx.gw `
            -Dns $netCtx.dns
        Write-BaseCapRunnerLifecycleTelemetry -Action 'flare_runner_completed' -Status 'timeout' -Reason $timeoutReason -NetworkContext $netCtx -VpnState $vpnState -DurationSec ([string]$elapsed)
        # Preserve the best known authoritative preflight context so the full
        # runner does not blindly fall back to http://enroll.cisco.com when a
        # real redirect was empirically observed.
        Write-BaseCapPreflightHandback -Observation $basePreflightObservation -DispatchContext $dispatchContext
        if ($BaseAllowFullEscalation) {
            Send-EscalationFlare
        }
    }

    if ($baseRedirectFinding) {
        Write-BaseCapLog "Base-discovered redirect finding: url='$($basePreflightObservation.redirect_url)' classification='$($basePreflightObservation.redirect_type)' attempt='$($basePreflightObservation.attempt)' - reported for follow-up routing only, Base took no remediation action" "WARN"
        if ($basePreflightObservation.redirect_type -eq 'ISE_EMPLOYEE') {
            # Observe-only by design: Main owns the ISE posture rescan. Base
            # records the classification as evidence for that decision.
            Write-BaseCapLog "Base observed ISE_EMPLOYEE (on-prem unpostured) in a retry - recorded as evidence and handed back to Main; Base performs NO posture rescan" "WARN"
        }
    }

    # Required F: clear the handoff artifact promptly so the next run sees
    # reality instead of this run's SSID/IP/gateway. It is intentionally kept
    # when Base escalated, because the full runner still has to consume it.
    if ($observed -or -not $BaseAllowFullEscalation) {
        Clear-BaseRemediationState -Reason $(if ($observed) { 'base_observed_resolution' } else { 'base_observe_only_timeout' })
    } else {
        Write-BaseCapLog "Remediation state artifact retained for the escalated full runner" "INFO"
    }
    Write-BaseCapLog "=== CPR-Base Complete ===" "INFO"

} catch {
    Write-BaseCapLog "Unhandled error in CPR-Base observer: $_" "FATAL"
    Write-CompletionFlag -Status "ERROR" -Details "Script error: $($_.Exception.Message)" -CaptiveBrowserPID 0
}

exit 0
